Adjunto una imagen del mapa conceptual para el mapa mental.
Además adjunto el pdf y un enlace donde se encuentra el mapa conceptual.

Enlace:
https://lucid.app/lucidchart/659def15-380a-4fe1-9243-bd8b6e38baa5/edit?invitationId=inv_be4db6a1-31bc-4789-86db-f221ab71202c
