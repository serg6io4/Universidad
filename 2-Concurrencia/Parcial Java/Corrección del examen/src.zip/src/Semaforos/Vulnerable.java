package Semaforos;

import java.util.Random;

public class Vulnerable extends Thread {
	private Tienda c;
	private int id;
	private Random r;
	public Vulnerable(int id, Tienda c)
	{
		this.id = id;
		this.c = c;
		r = new Random();
	}
	
	public void run() {
		while(true)
		{
			try {
				c.entraVulnerable(id);
				Thread.sleep(r.nextInt(100));//dentro del comercio
				c.saleVulnerable(id);
				Thread.sleep(r.nextInt(200));//se da un paseo
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
