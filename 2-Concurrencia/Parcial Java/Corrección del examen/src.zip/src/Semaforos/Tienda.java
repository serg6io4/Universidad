package Semaforos;

import java.util.concurrent.Semaphore;

public class Tienda {
	
	private Semaphore vulnerable;//Controla cuando se mete un vulnerable
	private int nInmunes;//Almacena vulnerables
	private int nVulnerable;//Habr� uno a lo sumo porque no puede estar en contacto
	private Semaphore mutex2;//nVulnerable
	private Semaphore mutex;//nInmunes
	private Semaphore justicia;//Controla que haya un poco de justicia
	private Semaphore mutex3;//Para que los vulnerables no esperen donde los inmunes
	
	public Tienda() {
		nInmunes=0;
		nVulnerable=0;
		mutex=new Semaphore(1);
		mutex2=new Semaphore(1);
		mutex3=new Semaphore(1);
		vulnerable=new Semaphore(1);
		justicia=new Semaphore(1);
		
	}
	
	public void entraInmune(int id) throws InterruptedException {
		mutex3.acquire();
		justicia.acquire();
		mutex.acquire();
		nInmunes++;
		System.out.println("Entra inmune:"+id);
		if(nInmunes==1)vulnerable.acquire();
		mutex.release();
		justicia.release();
		mutex3.release();
							
	}

	public void saleInmune(int id) throws InterruptedException {
		mutex.acquire();
		nInmunes--;
		System.out.println("Sale inmune: "+id);
		if(nInmunes==0)vulnerable.release();
		mutex.release();
	}

	public void entraVulnerable(int id) throws InterruptedException {		
		mutex2.acquire();
		nVulnerable++;
		if(nVulnerable==1)justicia.acquire();
		mutex2.release();
		vulnerable.acquire();
		System.out.println("Entra vulnerable");
		
	}

	public void saleVulnerable(int id) throws InterruptedException {
		System.out.println("Sale vulnerable");
		vulnerable.release();
		mutex2.acquire();
		nVulnerable--;
		if(nVulnerable==0)justicia.release();
		mutex2.release();
	}

}
