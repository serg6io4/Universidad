package Locks;
public class Tienda {
	
	
	public void entraInmune(int id) throws InterruptedException {
		//TODO	
							
	}

	public void saleInmune(int id) throws InterruptedException {
		//TODO
	}

	public void entraVulnerable(int id) throws InterruptedException {		
		//TODO	
	}

	public void saleVulnerable(int id) {
		//TODO
	}

}
