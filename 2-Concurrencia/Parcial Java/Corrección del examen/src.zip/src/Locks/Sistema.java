package Locks;
public class Sistema {

	public static void main(String[] args) {
		final int VULNERABLES = 4;
		final int INMUNES = 7;
		Tienda c = new Tienda();
		Vulnerable vulnerables[] = new Vulnerable[VULNERABLES];
		Inmune inmunes[] = new Inmune[INMUNES];
		for(int i =0; i< VULNERABLES; i++)
		{
			vulnerables[i]= new Vulnerable(i, c);
		}
		
		for(int i =0; i< INMUNES; i++)
		{
			inmunes[i]= new Inmune(i, c);
		}

		for(int i =0; i< VULNERABLES; i++)
		{
			vulnerables[i].start();
		}
		
		for(int i =0; i< INMUNES; i++)
		{
			inmunes[i].start();
		}
	}

}
