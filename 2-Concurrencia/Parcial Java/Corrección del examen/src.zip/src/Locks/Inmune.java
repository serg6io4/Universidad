package Locks;

import java.util.Random;

public class Inmune extends Thread {
	private Tienda c;
	private int id;
	private Random r;
	public Inmune(int id, Tienda c)
	{
		this.id = id;
		this.c = c;
		r = new Random();
	}
	
	public void run() {
		while(true)
		{	
			try {
				c.entraInmune(id);
				Thread.sleep(r.nextInt(100));//dentro del comercio
				c.saleInmune(id);
				Thread.sleep(r.nextInt(200));//se da un paseo
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
