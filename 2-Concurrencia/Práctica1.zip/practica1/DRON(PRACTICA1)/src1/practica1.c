/*
 ============================================================================
 Name        : Practica1.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description :
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "GestionMemoria.h"

int main(void) {

	T_Manejador manej;
	unsigned ok;
	unsigned dir;

	setvbuf(stdout,NULL,_IONBF,0);

	crear(&manej);
	mostrar(manej);

	obtener(&manej,500,&dir,&ok); /* Se ha hecho una foto. Se necesita memoria */
	if (ok) {
		printf("Se ha reservado un bloque de tamaño 500 en la direccion %d\n", dir);
		mostrar(manej);
	} else {
		printf("No es posible obtener esa memoria\n");
	}


	devolver(&manej, 200,0); /* Se ha enviado parte de la foto. Ya se puede borrar */
	printf("Se ha liberado un bloque de tamaño 200 en la dirección 0\n");
	mostrar (manej);


	obtener(&manej,50,&dir,&ok); /* Se ha hecho otra foto */
	if (ok) {
		printf("Se ha reservado un bloque de tamaño 50 en la direccion %d\n", dir);
		mostrar(manej);
	} else {
		printf("No es posible obtener 50\n");
	}


	devolver(&manej,100,400); /* Se ha enviado parte de la foto. Ya se puede borrar */
	printf("Se ha liberado un bloque de tamaño 100 en la dirección 400\n");
	mostrar(manej);

 	obtener(&manej,250,&dir,&ok); /* Se ha hecho otra foto */
	if (ok) {
		printf("Se ha reservado un bloque de tamaño 250 en la direccion %d\n", dir);
		mostrar(manej);
	} else {
		printf("No es posible obtener 250\n");
	}

	obtener(&manej,350,&dir,&ok); /* Se ha hecho otra foto */
	if (ok) {
		printf("Se ha reservado un bloque de tamaño 350 en la direccion %d\n", dir);
		mostrar(manej);
	} else {
		printf("No es posible obtener 250\n");
	}

	devolver(&manej, 200,750); /* Se ha enviado parte de la foto. Ya se puede borrar */
	printf("Se ha liberado un bloque de tamaño 200 en la dirección 750\n");
	mostrar(manej);


	destruir(&manej);
	printf("Se ha destruido el manejador de memoria\n");
	mostrar (manej);

	printf("Fin Programa\n");

	return EXIT_SUCCESS;
}
