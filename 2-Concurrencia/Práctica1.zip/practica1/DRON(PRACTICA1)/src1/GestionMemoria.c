/*
 * GestionMemoria.c
 *
 *  Created on: 6 mar. 2020
 *      Author: alumno
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>//Si queremos mostrar errores mediante perror
#include "GestionMemoria.h"

/* Crea la estructura utilizada para gestionar la memoria disponible. Inicialmente, s�lo un nodo desde 0 a MAX */
	void crear(T_Manejador* manejador){
		*manejador = (struct T_Nodo*) malloc(sizeof(struct T_Nodo));
		//*manejador = (T_Manejador) malloc(sizeof(struct T_Nodo));
		if(*manejador!=NULL){
			(*manejador)->inicio = 0;
			(*manejador)->fin = 999;
			(*manejador)->sig = NULL;
		}else{
			perror("No tenemos memoria suficiente.\n");
		}
	}

/* Destruye la estructura utilizada (libera todos los nodos de la lista. El par�metro manejador debe terminar apuntando a NULL */
	void destruir(T_Manejador* manejador){
		T_Manejador aux= *manejador;
		while(*manejador!=NULL){
			aux = *manejador;
			*manejador= (*manejador)->sig;
			free(aux);//liberar memoria al nodo al que estoy apuntando
		}
	}

/* Devuelve en �dir� la direcci�n de memoria �simulada� (unsigned) donde comienza el trozo de memoria continua de tama�o �tam� solicitada.
Si la operaci�n se pudo llevar a cabo, es decir, existe un trozo con capacidad suficiente, devolvera TRUE (1) en �ok�; FALSE (0) en otro caso.
 */
	void obtener(T_Manejador *manejador, unsigned tam, unsigned* dir, unsigned* ok){
		T_Manejador ptr, ant;
		ptr= *manejador;
		ant = NULL;
		while(ptr !=NULL && (ptr->fin - ptr->inicio+1)<tam){
			ant=ptr;
			ptr = ptr->sig;
		}

		if(ptr==NULL){
			//Significa que no hay bloque de tama�o suficiente
			*ok=0;
		}else{
			*ok=1;
			*dir = ptr->inicio;
			if((ptr->fin - ptr->inicio+1)==tam){
				//el bloque es de tama�o tam y hay que borrarlo
				if(ant!=NULL){//Elimino bloque intermedio o final
					ant->sig= ptr->sig;
				}else{//Elimino bloque del principio
					*manejador= (*manejador)->sig;
				}
				free(ptr);
			}else{
				//El bloque es de tama�o mayor a tam(actualiza la direcci�n de memoria del puntero
				ptr->inicio=ptr->inicio +tam;
			}
		}
	}

/* Muestra el estado actual de la memoria, bloques de memoria libre */
	void mostrar (T_Manejador manejador){
		T_Manejador aux = manejador;
		while(aux!=NULL){
			printf("Bloque inicio: %d - fin: %d \n", aux->inicio, aux->fin);
			aux= aux->sig;
		}
	}

/* Devuelve el trozo de memoria continua de tama�o �tam� y que
 * comienza en �dir�.
 * Se puede suponer que se trata de un trozo obtenido previamente.
 */
	void compactar(T_Manejador *manejador){//funcion auxiliar
		T_Manejador ptr, ant;
		ptr = *manejador;
		ant = NULL;
		while(ptr!=NULL){
			if(ant!=NULL && (ptr->inicio == (ant->fin +1))){//hay que compactar
				ant->fin = ptr->fin;
				ant->sig = ptr->sig;
				free(ptr);
				ptr = ant ->sig;
			}else{
				ant= ptr;
				ptr= ptr->sig;
			}
		}

	}
	void devolver(T_Manejador *manejador,unsigned tam,unsigned dir){
		T_Manejador ptr, ant, nuevo;
		ptr = *manejador;
		ant=NULL;
		nuevo=(T_Manejador) malloc(sizeof(struct T_Nodo));
		nuevo->inicio = dir;
		nuevo->fin= dir+tam-1;

		while(ptr!=NULL && (ptr->inicio < dir)){
			ant=ptr;
			ptr = ptr->sig;
		}
		if(ant==NULL){//inserta en la primera posicion de la lista
			nuevo->sig=*manejador;
			*manejador = nuevo;
		}else{//inserta en posicion intermedia o final
			nuevo->sig= ant->sig;//nuevo si apunta a ptr
			ant->sig = nuevo;
		}
		compactar(manejador);
	}

