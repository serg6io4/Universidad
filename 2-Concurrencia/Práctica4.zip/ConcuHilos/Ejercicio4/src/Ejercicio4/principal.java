package Ejercicio4;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class principal {

	public static void main(String[] args) throws InterruptedException {
		List<Integer> lista =new ArrayList();
		Scanner reader = new Scanner(System.in);
		int numero = 0;

		System.out.println("Introduce n�meros. El cero para salir");

		do {			
		    numero = reader.nextInt();
		    lista.add(numero);
		} while (numero!=0);
		
		nodo n1 = new nodo(lista);
		n1.start();
		n1.join();
		
		Iterator iter = lista.iterator();
		while (iter.hasNext())
		  System.out.print(iter.next());
	}

}
