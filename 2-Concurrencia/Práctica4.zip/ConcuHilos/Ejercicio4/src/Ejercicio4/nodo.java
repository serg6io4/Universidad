package Ejercicio4;

import java.util.Collections;
import java.util.List;

public class nodo extends Thread{

	private List<Integer> lista;
	
	public nodo(List<Integer> lista) {
		this.lista=lista;
	}

	public void a�ade(List<Integer> I, int desde, int hasta) {
		for(int i=desde; i<hasta; i++) {
			I.add(i);
		}
	}
	public void mezclar(List<Integer>I1, List<Integer>I2) {
		I1.addAll(I2);
		Collections.sort(I1);
		lista=I1;
	}
	@Override 
	public void run() {
		if(lista.isEmpty()||lista.size()<1) {
			System.out.println("La lista ya est� ordenada");
		}else {
			mezclar(lista.subList(0, (lista.size()/2)-1),lista.subList((lista.size()/2)-1, lista.size()-1));
		}
	}
}
