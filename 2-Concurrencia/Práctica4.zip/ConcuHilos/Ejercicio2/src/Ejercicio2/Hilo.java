package Ejercicio2;

public class Hilo extends Thread {

	private String name;
	private int id;
	private VariableCompartida v1;
	
	public Hilo(String name, int id, VariableCompartida v1) {
		this.name=name;
		this.id=id;
		this.v1=v1;
	}
	
	@Override
	public void run() {
		for(int i=0;i<10;i++) {
			v1.inc(1);
			System.out.println(name+" "+id+", Valor de v1: "+v1.get());
		}
	}
	
}
