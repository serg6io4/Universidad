package Ejercicio2;

public class principal {

	public static void main(String[] args) throws InterruptedException {
		VariableCompartida v1 = new VariableCompartida();
		Hilo h1 = new Hilo("Proceso",1,v1);
		Hilo h2 = new Hilo("Proceso",2,v1);
		
		h1.start();
		h2.start();
		
	}

}
