package Ejercicio5;

public class principal {

	public static void main(String[] args) throws InterruptedException {
		Fibonacci f1 = new Fibonacci(9);
		f1.start();
		f1.join();
		System.out.println("El valor de la salida es "+f1.getSalida());
	}

}
