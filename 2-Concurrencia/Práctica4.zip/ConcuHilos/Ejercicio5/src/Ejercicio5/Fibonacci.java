package Ejercicio5;

public class Fibonacci extends Thread{

	private int x;
	private int salida;
	
	public Fibonacci(int x) {
		this.x=x;
	}
	@Override 
	public void run() {
		if(x==0) {
			salida=0;
		}else if(x==1 || x==2) {
			salida=1;
		}else {
			Fibonacci f1 = new Fibonacci(x-1);
			Fibonacci f2 = new Fibonacci(x-2);
			Thread fprimero = new Thread(f1);
			Thread fsegundo = new Thread(f2);
			
			fprimero.start();
			try {
				fprimero.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			fsegundo.start();
			try {
				fsegundo.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			salida=f1.getSalida()+f2.getSalida();
		}
	}
	public int getSalida() {
		return salida;
	}
}
