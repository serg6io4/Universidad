package Ejercicio1;

public class principal {

	public static void main(String[] args) {
		Hilo h1 = new Hilo("Hilo", 1, "A");
		Hilo h2 = new Hilo("Hilo", 2, "B");
		Hilo h3 = new Hilo("Hilo", 3, "C");
		
		h1.start();
		h2.start();
		h3.start();

	}

}
