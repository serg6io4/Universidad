package Ejercicio1;

public class Hilo extends Thread{

	private String name;
	private int id;
	private String word;
	
	public Hilo(String name, int id, String word) {
		this.name=name;
		this.id=id;
		this.word=word;
	}
	@Override
	public void run() {
		for(int i=0; i<10;i++) {
			System.out.println("Nombre: "+name+",ID: "+id+",Letra: "+word);
		}
	}
}
