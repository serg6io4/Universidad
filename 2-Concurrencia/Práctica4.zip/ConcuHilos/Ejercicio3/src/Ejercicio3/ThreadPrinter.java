package Ejercicio3;

public class ThreadPrinter extends Thread{

	private VariableCompartida v1;
	private int id;
	private String nombre;
	
	public ThreadPrinter(String nombre, int id, VariableCompartida v1) {
		this.nombre=nombre;
		this.id=id;
		this.v1=v1;
	}
	@Override 
	public void run() {
		int i=0;
		while(i<=99) {
			System.out.println("El valor de v1 es "+v1.get());
			i++;
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
