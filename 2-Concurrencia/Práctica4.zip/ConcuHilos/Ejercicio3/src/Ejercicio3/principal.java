package Ejercicio3;

public class principal {

	public static void main(String[] args) {
		VariableCompartida v1 = new VariableCompartida();
		ThreadWriter t1 = new ThreadWriter("proceso",1,v1);
		ThreadPrinter t2 = new ThreadPrinter("proceso",2,v1);
		
		t1.start();
		t2.start();
	}

}
