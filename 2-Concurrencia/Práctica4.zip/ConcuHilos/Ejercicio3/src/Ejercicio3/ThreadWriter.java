package Ejercicio3;

public class ThreadWriter extends Thread {

	private VariableCompartida v1;
	private int id;
	private String nombre;
	
	public ThreadWriter(String nombre, int id, VariableCompartida v1) {
		this.nombre=nombre;
		this.id=id;
		this.v1=v1;
	}
	@Override
	public void run() {
		int i=0;
		while(i<=99) {
			v1.set(i);
			i++;
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
