package Ejercicio3;

public class VariableCompartida {
	private int value;
	
	public void set(int actualvalue) {
		value=actualvalue;
	}
	public int get() {
		return value;
	}
	public void inc(int newValue) {
		value+=newValue;
	}
}
