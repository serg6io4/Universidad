
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include "arbolbb.h"

typedef struct T_Nodo* T_Arbol;

struct T_Nodo {
unsigned dato;
T_Arbol izq, der;
};


// Crea la estructura utilizada para gestionar el árbol.
void crear(T_Arbol* arbol){
	(*arbol)==NULL;//Como no nos pasan nada lo pongo vac�a
}
// Destruye la estructura utilizada y libera la memoria.
void destruir(T_Arbol* arbol){
	if(*arbol){
		//si tengo un �rbol destruyo ese dato
		//junto con su izquierda y la derecha
		//por lo que se puede hacer recursivo
		destruir(&((*arbol)->der));
		destruir(&((*arbol)->izq));
		free((*arbol));
	}
}
// Inserta num en el árbol. Si ya está insertado, no hace nada
void insertar(T_Arbol* arbol,unsigned num){
	if((*arbol)==NULL){
		(*arbol) = (T_Arbol)malloc(sizeof(struct T_Nodo));
		(*arbol)->dato=num;
		(*arbol)->izq=NULL;
		(*arbol)->der=NULL;
		//creo que se puede hacer con el crear
		//que hay al principio pero no me fio
	}else if((*arbol)->dato > num){
			insertar(&(*arbol)->der, num);
	}else if((*arbol)->dato < num){
			insertar(&(*arbol)->izq, num);
	}

}

// Muestra el contenido del árbol en InOrden
void mostrar(T_Arbol arbol){
	//InOrden: izq, dato, der
	if((*arbol)==NULL){
		mostrar((*arbol)->izq);
		printf("%d",(*arbol)->dato);
		mostrar((*arbol)->der);
	}

}
// Guarda en disco el contenido del fichero
void salvar(T_Arbol arbol, FILE* fichero){
	//Hago lo mismo que mostrar pero meti�ndolos
	//en un fichero
	//Como ya tengo un manejador, puedo usar fwrite
	if((*arbol)==NULL){
		//Lo escribo en InOrden
		salvar((*arbol)->izq, fichero);
		fwrite(&(arbol->dato),sizeof(unsigned),1,fichero);
		salvar((*arbol)->der, fichero);
	}
}

