/*
 * principal.c
 *
 *  Created on: 21 mar. 2019
 *      Author: Laura
 */


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include "arbolbb.h"

void crearFicheroAleatorios(char *nombreFich, int TAM)
{
	FILE *ptr = fopen(nombreFich, "wb");
	if(ptr == NULL){
		perror("No se ha podido abrir el fichero");
	}else{
		int num;
		int i;
		for(i=0;i<TAM;i++){
			num = rand()%TAM;
			fwrite(&num, sizeof(int),1,ptr);
		}
		fclose(ptr);
	}
}

void mostrarFicheroAleatorios(char *nombreFich)
{
	FILE *ptr = fopen(nombreFich,"rb");
	if(ptr==NULL){
		perror("No se ha podido abrir el archivo");
	}else{
		int num;
		while(fread(&num, sizeof(int),1,ptr)==1){
			printf("%d",num);
		}
		printf("/n");
		fclose(ptr);
	}
}

void cargaFichero(char* nfichero, T_Arbol* miarbol)
{
	FILE *ptr = fopen(nfichero, "rb");
	int num;
	if(ptr==NULL){
		perror("No se ha podido abrir el fichero");
	}else{
		while(fread(&num, sizeof(int),1,ptr)==1){
			insertar(miarbol,num);
		}
		fclose(ptr);
	}
}

int main(int argc, char **argv)
{
	int TAM;
	char nombreFich[30];

	setvbuf(stdout, NULL, _IONBF, 0);
	printf("Introduzca nombre fichero:\n");
	scanf("%s", nombreFich);

	printf("Introduzca tamaño:\n");
	scanf("%d", &TAM);

	crearFicheroAleatorios(nombreFich, TAM);
	mostrarFicheroAleatorios(nombreFich);

	printf ("\n Ahora lo cargamos en el arbol\n");
	T_Arbol miarbol;
	crear (&miarbol);
	cargaFichero(nombreFich,&miarbol);
	printf ("\n Y lo mostramos ordenado\n");
	mostrar(miarbol);

	printf("\n Ahora lo guardamos ordenado\n");
	FILE * fich;
	fich = fopen (nombreFich, "wb");
	salvar (miarbol, fich);
	fclose (fich);
	printf("\n Y lo mostramos ordenado\n");
	mostrarFicheroAleatorios(nombreFich);
	destruir (&miarbol);

}













































