package Practica5;

public class Consumidor extends Thread {
	private BufferCircular b;
	private int iter;
	public Consumidor(BufferCircular b, int iter) {
		this.b=b;
		this.iter=iter;
	}
	@Override
	public void run() {
		for(int i=0; i<iter;i++) {
			System.out.println("Extrayendo "+b.extraer());
		}
	}
}
