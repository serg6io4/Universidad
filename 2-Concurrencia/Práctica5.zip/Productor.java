package Practica5;

public class Productor extends Thread{
	private BufferCircular b;
	private int iter;
	public Productor(BufferCircular b, int iter) {
		this.b=b;
		this.iter=iter;
	}
	@Override
	public void run() {
		for(int i=0; i<iter;i++) {
			System.out.println("Insertando: "+ i);
			b.insertar(i);
		}
	}
}
