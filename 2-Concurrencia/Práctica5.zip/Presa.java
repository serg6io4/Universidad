package Practica5_2;

public class Presa extends Thread{
	private Lago lago;
	private int id;
	public Presa(Lago lago, int id) {
		this.lago=lago;
		this.id=id;
	}
	@Override
	public void run() {
		for(int i=0; i<1000;i++) {
			if(id==0) {
				lago.decrementarR0();
			}else {
				lago.decrementarR1();
			}
		}
	}
}
