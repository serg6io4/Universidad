package Practica5_2;

public class Rio extends Thread{
	private Lago lago;
	private int id;
	public Rio(Lago lago, int id) {
		this.lago=lago;
		this.id=id;
	}
	@Override
	public void run() {
		for(int i=0; i<1000;i++) {
			if(id==0) {
				lago.incrementarR0();
			}else {
				lago.incrementarR1();
			}
		}
	}
}
