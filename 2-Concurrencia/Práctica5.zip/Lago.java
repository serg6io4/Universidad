package Practica5_2;

public class Lago {

	private int nivelInicial;
	//Variable Peterson
	private volatile boolean fRio1=false, fRio0=false;
	private volatile int turnoRios=0;
	private volatile boolean fPresa1= false, fPresa0=false;
	private volatile int turnoPresas=0;
	private volatile boolean fRio= false, fPresa=false;
	//fRio=true turnoRioPresa = 0;
	//fPresa=true turnoRioPresa =1;
	private volatile int turnoRioPresa=0;//
	
	public Lago(int nivelInicial) {
		this.nivelInicial=nivelInicial;
	}
	
	public int getNivelInicial() {
		return nivelInicial;
	}

	public void incrementarR0() {
		fRio0=true;
		turnoRios=1;
		while(fRio1 && turnoRios==1) {
			Thread.yield();
		}
		//El rio 0 ha pasado
		//PreProtocolo entre r0 y presas
		fRio=true;
		turnoRioPresa=1;
		while(fPresa&&turnoRioPresa==1) {
			Thread.yield();
		}
		//SC R0
		nivelInicial++;
		fRio0=false;
		fRio=false;
	}

	public void incrementarR1() {
		fRio1=true;
		turnoRios=0;
		while(fRio1 && turnoRios==0) {
			Thread.yield();
		}
		//El rio 1 ha pasado
		//PreProtocolo entre r1 y presas
		fRio=true;
		turnoRioPresa=1;
		while(fPresa&&turnoRioPresa==1) {
			Thread.yield();
		}
		//SC R0
		nivelInicial++;
		fRio1=false;
		fRio=false;
	}

	public void decrementarR0() {
		while(nivelInicial==0) {
			System.out.println("No hay agua");
			Thread.yield();
		}
		fPresa0=true;
		turnoPresas=1;
		while(fPresa1&&turnoPresas==1) {
			Thread.yield();
		}
		fPresa=true;
		turnoRioPresa=0;
		while(fRio&&turnoRioPresa==0) {
			Thread.yield();
		}
		//Secci�nCr�tica
		nivelInicial--;
		//PostPortocolo
		fPresa0=false;
		fPresa=false;
	}

	public void decrementarR1() {
		while(nivelInicial==0) {
			System.out.println("No hay agua");
			Thread.yield();
		}
		fPresa1=true;
		turnoPresas=0;
		while(fPresa1&&turnoPresas==0) {
			Thread.yield();
		}
		fPresa=true;
		turnoRioPresa=0;
		while(fRio&&turnoRioPresa==0) {
			Thread.yield();
		}
		//Secci�nCr�tica
		nivelInicial--;
		//PostPortocolo
		fPresa1=false;
		fPresa=false;
		
	}
	
}
