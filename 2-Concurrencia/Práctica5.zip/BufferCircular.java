package Practica5;
//Realizar Petterson pero con buffer
public class BufferCircular {
	private int [] elem;
	private int p;
	private int c;
	private int nelem=0;
	private int N;
	//Variables de Petterson para control
	public volatile boolean fp, fc;
	private volatile int turno; //0 productor, 1 consumidor
	
	public BufferCircular(int N) {
		this.p=0;
		this.c=0;
		this.nelem=0;
		this.elem=new int [N];
		this.N=N;
	}
	public void insertar(int i) {
		while(nelem==elem.length) {
			System.out.println("Si no hay espacio no puedo producir");
			Thread.yield();
		}
		//PreProtocolo Productor
		fp=true;
		turno=1;
		while(fc && turno==1) {
			Thread.yield();
		}
		//Secci�n cr�tica
		elem[p]=i;
		p=(p+1)%elem.length;
		nelem++;
		
		//PostProtocolo Productor
		fp=false;
		
		}
	
	public int extraer() {
		int elemento;
		while(nelem==0) {
			System.out.println("No hay elementos que consumir");
			Thread.yield();
		}
		//PreProtocolo consumidor
		fc=true;
		turno=0;
		while(fp&&turno==0) {
			Thread.yield();
		}
		//secci�n cr�tica
		elemento=elem[c];
		c=(c+1)%elem.length;
		nelem--;
		//Post protocolo consumidor
		fc=false;
		
		return elemento;
	}
	//M�todos para obtener cosas porque lo he puesto privado
	public int[] getElem() {
		return elem;
	}
	public int getP() {
		return p;
	}
	public int getC() {
		return c;
	}
	public int getNelem() {
		return nelem;
	}
}
