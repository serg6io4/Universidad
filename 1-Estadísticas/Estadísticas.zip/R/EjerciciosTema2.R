#Ejercicio 10
x<-c(1,2,3,4,5)
y<-c(1, 0.5, 0.33, 0.25, 0.2)
##La fórmula es y = 1/a+bx
#Que sería 1/y = a +bx

lm((1/y) ~x)

ypred <- 1/(0.006061 + x)

MSE <- mean((y-ypred)^2)
varY <- mean(y^2)-mean(y)^2
R2 <- 1 - MSE/varY

#Ejercicio 9
x<-c(1,2,3,4,5)
y<-c(0.5,2,4.5,8,12.5)

# y = a * x^b -> y = a + bx
#lny = lna + lnx^b -> lny = lna + b*lnx
mod <- lm(log(y)~log(x))

coef <- mod$coefficients

ypred <- exp(coef[1]) * x ^ coef[2]

MSE <- mean((y-ypred)^2)
varY <- mean(y^2) - mean(y)^2
R2 <- 1 - MSE/varY
R2
