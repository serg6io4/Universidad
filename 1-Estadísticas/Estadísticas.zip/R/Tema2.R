library(tidyverse)
dfMec <- read_csv('C:/Users/sergi/Desktop/R/dfMec.csv')
dfMec

#Regresión lineal simple
df1 <- dfMec %>% select(notaFinal, notaBach)##para seleccionar una parte
df1

covxy <- mean(df1$notaFinal * df1$notaBach) - 
                mean(df1$notaFinal)*mean(df1$notaBach) 
varX <- mean(df1$notaBach ^ 2) - mean(df1$notaBach) ^ 2
vary <- mean(df1$notaFinal ^ 2) - mean(df1$notaFinal) ^ 2
covxy / varX
mean(df1$notaFinal)
mean(df1$notaBach)

# y - 4.30 = 0.21 * (x - 7.08)

#Coeficiente de correlación lineal de Pearson(r)
covxy / sqrt(varX * vary)

#Coeficiente de correlacion Lineal de Pearson (r^2)
covxy ^ 2 / (varX*vary)

mod<-lm(notaFinal ~ notaBach, dfMec)
summary(mod)$r.squared
names(mod)
mod$coefficients

plot(df1$notaBach, df1$notaFinal)
abline(mod)#pinta la recta de regresión
predict.lm(mod)#predicción de los datos de la regresión

df1$notaPredicha <- predict.lm(mod)

df1 %>%
  mutate(notaPredicha = predict.lm(mod), err=notaFinal-notaPredicha)%>%
           summarise(MSE = mean(err ^ 2), varY=mean(notaFinal^2) -mean(notaFinal)^2,
                     R2=1- MSE/varY)
