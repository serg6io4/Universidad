##############
#EJERCICIO 1 #
##############
pa <- c(9.47, 9.26, 8.86, 8.25, 7.81, 8.01, 7.55, 7.24, 7.01, 6.88, 7.03)
# a) Caculamos la tendencia para media móvil 4 y 5
tpa <- stats::filter(pa, c(.5,1,1,1,.5)/4)
tpa2 <- stats::filter(pa, c(1,1,1,1,1)/5)

tt <- 1:11

mod <- lm(tpa ~ tt)
summary(mod)

##############
#EJERCICIO 4 #
##############
ee <- c(178.2,156.7,164.2,153.2,157.5,172.6,185.9,185.8,165.0,163.6,169.0,183.1,
        196.3,162.8,168.6,156.9,168.2,180.2,197.9,195.9,176.0,166.4,166.3,183.9,
        197.3,173.7,173.2,159.7,175.2,187.4,202.6,205.6,185.6,175.6,176.3,191.7,
        209.5,186.3,183.0,169.5,178.2,186.7,202.4,204.9,180.6,179.8,177.4,188.9,
        200.0,188.7,187.5,168.6,175.7,189.4,216.1,215.4,191.5,178.5,178.6,195.6,
        205.2,179.6,185.4,172.4,177.7,202.7,220.2,210.2,186.9,181.4,175.6,195.6)
tee <- stats::filter(ee, c(.5,1,1,1,.5)/4)
#componente estacional *aleatoria
est_aleEE <- ee / tee
#Apartado A)componente estacional sin normalizar
est1EE <- colMeans(matrix(est_aleEE, ncol=4, byrow =T),na.rm = T)
#Apartado A)Normalizo la componente estacional
estEE  <- est1EE / mean(est1EE)

#Apartado B) Desestacionalizar
destEE <- ee / estEE
#Apartado C) Representar gráfico con originales y desestacionalizados
plot(ee)
lines(destEE, col=4)

# Apartado D) Calculo tendencia real
xx <- 1:72
mod <- lm(destEE ~ xx)
summary(mod)

#Apartado E) componente aleatoria y cíclica

aleEE <- est_aleEE/estEE

