###############
# Ejercicio 04#
###############
d <- c(43,55,40,52,39,33,50,33,44,21)
v <- c(27, 23.8,30.7,24,34.8,41.4,27,40.4,31.7,51.2)
summary(lm(v~d))
covxy <- mean(d*v) - mean(d) * mean(v)
varX <- mean(d ^ 2) - mean(d) ^ 2
varY <- mean(v ^ 2) - mean(v) ^ 2

r <- covxy / sqrt(varX * varY)
r2 <- covxy ^ 2 / (varX*varY)#Este es el que muestra r


###############
# Ejercicio 08#
###############
x<-c(1, 2, 3, 4, 5)
y<-c(3.0, 4.5, 7.0, 10.0, 15.0)

#Predecir por y = a * b^x >> lny = lna + x*lnb
Y<- log(y)
mod1 <- lm(Y~x)
summary(mod1)
exp(0.70663)
exp(0.40174)
#La regresión es: y = 2.027148*1.494423^x
covxy <- mean(x*y) - mean(x)*mean(y)
varX <- mean(x^2)-mean(x)
varY <- mean(y^2)-mean(y)

r<-covxy/sqrt(varX*varY)
r
yp <- 2.027148*1.494423^x
yp
MSE <- sum((y-yp)^2)/5
R2 <- 1 - (MSE/varY)
R2

###############
# Ejercicio 09#
###############
x <- c(1, 2, 3, 4, 5)
y <- c(0.5, 2.0, 4.5, 8.0, 12.5)

#Predecir por y = a*x^b >> lny = lna + b*lnx
Y <- log(y)
X <- log(x)

mod1 <- lm(Y~X)
summary(mod1)

###############
# Ejercicio 10#
###############
x <- c(1, 2, 3, 4, 5)
y <- c(1, 0.50, 0.33, 0.25, 0.20)
#Predecir por y = 1/(a + bx)
# 1/y = a + bx
Y <- 1/y
mod1 <- lm(Y~x)
summary(mod1)$r.squared



###############
# Ejercicio 11#
###############
x <- c(1, 2, 3, 4, 5)
y <- c(1, 1, 2, 4, 8)
mod1  <- lm(y~x)
coef1 <- mod1$coefficients
summary(mod1)$r.squared

z <- log(y)
mod2  <- lm(z~x)
coef2 <- exp(mod2$coefficients)
# OJO: Este valor no es el que hay que utilizar. Es el R2 de z. NO nos vale
summary(mod2)$r.squared

# y predichas por el modelo 1 (dos maneras eq de calcularlo)
predict.lm(mod1)
yp1 <- coef1[1] + coef1[2] * x

# y predichas por el modelo 2
exp(predict.lm(mod2))
yp2 <- coef2[1] * coef2[2] ^ x

# R2 
MSE1 <- mean((y - yp1)^2)
MSE2 <- mean((y - yp2)^2)
varY <- mean(y^2) - mean(y)^2

R2_1 <- 1 - MSE1/varY
R2_2 <- 1 - MSE2/varY

# Como R2_2 es mayor, el modelo 2 es mejor

# Predicci�n de los modelos para 6 y 10
coef1[1] + coef1[2] * c(6, 10)
coef2[1] * coef2[2] ^ c(6, 10)

# Predicci�n de los modelos para 6 y 10 usando predict.lm
predict.lm(mod1, data.frame(x=c(6,10)))
exp(predict.lm(mod2, data.frame(x=c(6,10))))


###############
# Ejercicio 13#
###############

Carga <- c(2, 4, 6, 8, 10, 12)
Ex <- c(10, 19, 29, 40, 48, 56)

#El modelo que piden es E= aC
mod2 <- lm(Ex ~ Carga + 0)
summary(mod2)

###############
# Ejercicio 14#
###############
x<-c(5,5,5,5,10,10,10,10,15,15,15,15,20,20,20,20)
y<-c(1,2,3,4,1,2,3,4,1,2,3,4,1,2,3,4)
z<-c(28,30,48,74,29,50,57,42,20,24,31,47,9,18,22,31)

mod1 <- lm(z ~ x + y)
summary(mod1)

###############
# Ejercicio 15#
###############

x<- c(1,1,2,2,2,1,2)
y<- c(2,4,2,2,4,4,4)
z<- c(1,3,4,5,3,3,5)

mod1 <- lm(z ~ x + y)
summary(mod1)$r.squared

#Ajusta para z = a + b*lnxy
# z = a + blnx + blny
X <- log(x)
Y <- log(y)
mod2 <- lm(z ~ X + Y)
summary(mod2)$r.squared
