#Todo puede ser un vector
#USANDO LA FUNCIÓN CONCATENATE(c)

x<- c(1,2)
y<- c(3,6,7,11)
z <- c(x,y)

a<- c(TRUE, FALSE, TRUE)
b<- c("cdf", "fdf")

#Vector que va del 1 al 10
1:10
#Este va de 2 en 2
#seq(inicio, fin, intervalo)
seq(1,10,2)

#Recupera los números de los índices dados 
z[c(3,4,6)]
x[2:5]
#NA sale cuando no existe ese número
