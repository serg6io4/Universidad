#Si colocas una línea solo, sin llaves
#Aquí lo que hacemos es meter la función
#dentro de la variable
ff<-function(x,y){
  x+2* y
}

ff(2,3)
ff(1:5, 11:15)
#Si por ejemplo, no le doy y pues sería 10
#es por defecto
ff2<-function(x,y=10){
  x+2* y
}
ff2(2,3)
ff2(3)
#Si nombro los argumentos puedo ponerlos
#en el orden que quiera
ff(y=100, x=2)
