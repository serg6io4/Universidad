###############
# Ejercicio 08#
###############
x<-c(1, 2, 3, 4, 5)
y<-c(3.0, 4.5, 7.0, 10.0, 15.0)

#Predecir por y = a * b^x >> lny = lna + x*lnb
Y<- log(y)
mod1 <- lm(Y~x)
summary(mod1)
exp(0.70663)
exp(0.40174)
#La regresión es: y = 2.027148*1.494423^x
covxy <- mean(x*y) - mean(x)*mean(y)
varX <- mean(x^2)-mean(x)
varY <- mean(y^2)-mean(y)

r<-covxy/sqrt(varX*varY)
r
yp <- 2.027148*1.494423^x
yp
MSE <- sum((y-yp)^2)/5
R2 <- 1 - (MSE/varY)
R2