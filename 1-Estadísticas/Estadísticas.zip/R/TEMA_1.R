
#---------------------------------
#EJERCICIO 2
#---------------------------------
#Calcular medidas de tendencia central
#Medidas de dispersión
#Medidas de simetría y apuntamiento

a<- c(6.7,6.3,6.5,6.5,6.4,6.6)
b<- c(1284, 1001, 911, 1168, 963, 1279, 1494, 798, 1599, 1357, 1090, 1082,
      1494, 1684, 1281, 590, 960, 1310, 1571, 1355, 1502, 1251, 1666, 778, 1200,
      849, 1454, 919, 1484, 1550, 628, 1325, 1073, 1273, 1710, 1734, 1928, 1416,
      1465, 1608, 1367, 1152, 1393, 1339, 1026, 1299, 1242, 1508, 705, 1199, 1155,
      822, 1448, 1623, 1084, 1220, 1650, 1091, 210, 1058, 1930, 1365, 1291, 683,
      1399, 1198, 518, 1199, 2074, 811, 1137, 1185, 892, 937, 945, 1215, 905,
      1810, 1265)
#Medidas de tendencia central(para a y b)
#Media 
mean(a)
mean(b)
#Mediana 
median(a)
median(b)
#cuantiles .25, .50, .75
quantile(a)
quantile(b)

#Medidas de dispersión(para a y b)
#varianza 
mean((a - mean(a))^2)
mean((b - mean(b))^2)
#Desviación típica
sqrt(mean((a - mean(a))^2))
sqrt(mean((b - mean(b))^2))

#Medidas de simetría y apuntamiento
#Necesitamos momentos ordinarios y centrales
#Momentos ordinarios
mean(a^2)#Momento ordinario 2
mean(b^2)
#Momentos centrales(3 y 4)
mean((a-mean(a))^3)
mean((a-mean(a))^4)
mean((b-mean(b))^3)
mean((b-mean(b))^4)
#También tenemos esto:
Mord   <- function(data, n) mean(data^n)
Mcentr <- function(data, n) mean((data - mean(data))^n)

#Sabiendo esto calculamos asimetría de Fisher
# Recuerda que momento central 2 es igual a la varianza
#Así que elevo a 3/2 y ya tengo sigma elevado a 3
Mcentr(a, 3)/ Mcentr(a,2) ^(3/2)
Mcentr(b, 3)/ Mcentr(b,2) ^(3/2)
#Calculamos coeficiente de apuntamiento
(Mcentr(a, 4)/ Mcentr(a,2) ^ 2)-3
(Mcentr(b, 4)/ Mcentr(b,2) ^(2))-3


#---------------------------------
#EJERCICIO 11
#---------------------------------
#NME:7.8, DE:0.8, NMC:7.3, DC:0.76
#¿En qué materia hay más dispersión? En cálculo hubo más dispersión
CVe <- 0.8/7.8
CVc <- 0.76/7.3
#Si un alumno saca NE:7.5 y NC: 7.1. ¿En qué examen sobresalió más ?
ZE <- (7.5 - 7.8)/0.8
ZC <- (7.1 - 7.3)/0.76#Sobresalió más en cálculo porque está más alejada
                      # de la media

#---------------------------------
#EJERCICIO 19
#---------------------------------

d <- c(1.17,1.61,1.16,1.38,3.53,1.23,3.76,1.94,0.96,4.75,0.15,
       2.41,0.71,0.02,1.59,0.19,0.82,0.47,2.16,2.01,0.92,0.75,
       2.59,3.07,1.40)
rq <- quantile(d, .75) - quantile(d, .25)
Ii <- 1.5 * rq
Is <- 1.5 * rq
Ei <- 3 * rq
Es <- 3 * rq

d[d < Ii]
d[d > Is]
d[d < Ei] 
d[d > Es]
