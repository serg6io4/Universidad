x<-c(1,1,2,2,3,3,4)
y<-c(0.5,0.4,1,1,2,1.5,3)
Y<-log(y)
mod1 <- lm(Y~x)
summary(mod1)
exp(-1.37367)
exp(0.63772)
#La recta queda tal que: y = 0.253161*1.892162^x
covxy <- mean(x*y) - mean(x)*mean(y)
varX <- mean(x^2)-mean(x)
varY <- mean(y^2)-mean(y)

r <- covxy/sqrt(varX*varY)

Y<- 0.253161*1.892162^x
Y
MSE <- sum((y - Y)^2) /7
MSE
R2 <- 1 - (MSE/varY)
R2
