a<-2
b<-5
a+b
a<-2.5988
#Así se ponen comentarios
#Se puede almacenar diferentes cosas

#Las cadenas se pueden poner con 
#comillas dobles o simples
ss <- "esto es una cadena"
tt <- "esto es otra cadena"


#Tipo lógico(TRUE OR FALSE)
ll<- TRUE
tr<- FALSE
tr & tr
ll & ll 
ll | tr
