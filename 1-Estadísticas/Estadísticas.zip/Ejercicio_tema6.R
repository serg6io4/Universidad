#Ejercicio 1
n <- 50
s <- 4000

##A)¿Puede afirmar el fabricante que la vida media de esos neumaticos es mayor que 30000 km.?
e <- qnorm(.975) * 4000/sqrt(50)
c(32000-e, 32000+e)
#Si puede afirmarlo

##B)¿Hasta que numero de kilometros podrıamos afirmar que llega la vida media de los neumaticos 
#con el mismo nivel de confianza?
med<-(32000-(s*sqrt(n) * qnorm(0.975))) 
med

#Ejercicio 3
s<-sqrt(100)
x<-160      
n<-144      

#A)Intervalo confianza 0.95
e<- qnorm(0.975) * s/sqrt(n)
r1<-c(160-e, 160+e)

#B)Intervalo confianza 0.90
e<- qnorm(0.925) * s/sqrt(n)
r2<-c(160-e, 160+e)

#C)Cual es mas  preciso?
r1[2]-r1[1]< r2[2]-r2[1]
#por lo tanto el r2 es más preciso

#Ejercicio 4
e<-qnorm(0.975) * (sqrt((1.02^2/33)+(1.73^2/27)))
r<-(8.7-10.9)
c(r-e, r+e)

#Ejercicio 5
n1<-13
n2<-16
s1<- 28
s2<- 7
sp<- ((n1 -1)*(s1^2) + (n2-1)*(s2^2))/(13+16-2) 
e<- qt(0.975, (16+13-2)) * sqrt(sp) * sqrt(1/n1 + 1/n2)
c((13-16)-e, (13-16)+e)

ff <- function(n1, s1, n2, s2) ( (s1^2 / n1 + s2^2 / n2) ^ 2 / ((s1^2 / n1) ^ 2 / (n1 + 1) + (s2^2 / n2) ^ 2 / (n2 + 1)) - 2 )
e<- qt(0.975, ff(n1,s1,n2,s2)) * sqrt((s1^2)/n1 + (s2^2)/n2)
c((166-164.7)-e, (166-164.7)+e)
