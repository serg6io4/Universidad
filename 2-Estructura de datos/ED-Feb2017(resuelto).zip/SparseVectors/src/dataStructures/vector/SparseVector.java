/******************************************************************************
 * Student's name:
 * Student's group:
 * Data Structures. Grado en Informática. UMA.
******************************************************************************/

package dataStructures.vector;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

public class SparseVector<T> implements Iterable<T> {

    protected interface Tree<T> {

        T get(int sz, int i);

        Tree<T> set(int sz, int i, T x);
    }

    // Unif Implementation

    protected static class Unif<T> implements Tree<T> {

        private T elem;

        public Unif(T e) {
            elem = e;
        }

        @Override
        public T get(int sz, int i) {
            //Estoy en la hoja, devuelvo el elemento
            return elem;
        }

        @Override
        public Tree<T> set(int sz, int i, T x) {
            //Compruebo si soy la hoja o no
            if (sz==1){//Si el tamaño es uno, es que soy hoja
                return new Unif<T>(x);
            }else if(i < sz/2){//no lo soy tengo que crear un árbol y establecer esa hoja por su rama
                    return new Node<>(set(sz/2, i, x), this) ;//izquierda
            }else{
                    return new Node<>(this, set(sz/2, i-sz/2, x)) ;//derecha
            }

        }

        @Override
        public String toString() {
            return "Unif(" + elem + ")";
        }
    }

    // Node Implementation

    protected static class Node<T> implements Tree<T> {

        private Tree<T> left, right;

        public Node(Tree<T> l, Tree<T> r) {
            left = l;
            right = r;
        }

        @Override
        public T get(int sz, int i) {//Este método llegará hasta la hoja y utilizará del método unif cuando llegue
            if(sz/2 > i){
                return left.get(sz/2,i);
            }else{
                return right.get(sz/2, i-sz/2);
            }
        }

        @Override
        public Tree<T> set(int sz, int i, T x) {//lo mismo que el get
            if(i < sz/2){
                left =  left.set(sz/2,i, x);
            }else{
                right =  right.set(sz/2, i-sz/2, x);
            }
            simplify();//en caso de ser iguales pues simplifico
            return this; //devuelvo el árbol entero
        }

        protected Tree<T> simplify() {
            if(left instanceof SparseVector.Unif<T> && right instanceof SparseVector.Unif<T>
                    && left.get(1,0).equals(right.get(1,0))){//te dará las hojas de ambos
                return (Unif<T>) left;
            }
            return this;
        }

        @Override
        public String toString() {
            return "Node(" + left + ", " + right + ")";
        }
    }

    // SparseVector Implementation

    private int size;
    private Tree<T> root;

    public SparseVector(int n, T elem) {
        if(n<0){
            throw new VectorException("Negative not possible");
        }
        size = (int) Math.pow(2, n);
        root = new Unif<T>(elem);//Si todos los elementos son 1 pues será un Unif<T>
    }

    public int size() {
        return size;
    }

    public T get(int i) {
        if(i<0 || i>size){
            throw new VectorException("Not exist");
        }
        return root.get(size, i);//Uso del método get de Node
    }

    public void set(int i, T x) {//lo mismo
        if(i<0 || i>size){
            throw new VectorException("Not exist");
        }
        root = root.set(size, i, x);
    }

    @Override
    public Iterator<T> iterator() {
        return new SparseVectorIterator();
    }
    //Me creo una clase iterador con su nombre
    public class SparseVectorIterator implements Iterator<T> {
        int i;
        public SparseVectorIterator(){
            i=0;
        }
        @Override
        public boolean hasNext() {
            return i < size;
        }

        @Override
        public T next() {
            if(!hasNext()){
                throw new NoSuchElementException();
            }
            T x = root.get(size, i);
            i++;
            return x;
        }
    }

    @Override
    public String toString() {
        return "SparseVector(" + size + "," + root + ")";
    }
}
