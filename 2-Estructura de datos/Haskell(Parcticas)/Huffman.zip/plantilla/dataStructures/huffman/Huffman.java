package dataStructures.huffman;
/**
 * Huffman trees and codes.
 *
 * Data Structures, Grado en Informatica. UMA.
 *
 *
 * Student's name: Sergio Camacho Marín
 * Student's group: TARDEs
 */

 import dataStructures.dictionary.AVLDictionary;
 import dataStructures.dictionary.Dictionary;
 import dataStructures.list.ArrayList;
 import dataStructures.list.List;
 import dataStructures.priorityQueue.BinaryHeapPriorityQueue;
 import dataStructures.priorityQueue.PriorityQueue;
 import dataStructures.priorityQueue.WBLeftistHeapPriorityQueue;
 import dataStructures.searchTree.AVL;
 import dataStructures.set.Set;
 import dataStructures.set.AVLSet;
 import dataStructures.tuple.Tuple2;

 import java.util.Iterator;

public class Huffman {

    // Exercise 1  (0.75 puntos)
    public static Dictionary<Character, Integer> weights(String s) {
        AVLDictionary dic = new AVLDictionary();
        int n = 0;
    	for(char c: s.toCharArray()){
            if(dic.isDefinedAt(c)){
                n = (int) dic.valueOf(c);
                dic.insert(c, (n+1));
            }else{
                dic.insert(c, 1);
            }
        }
        return dic;
    }

    // Exercise 2.a (0.75 puntos)
    public static PriorityQueue<WLeafTree<Character>> huffmanLeaves(String s) {
        Dictionary<Character, Integer> dic = weights(s);
        PriorityQueue<WLeafTree<Character>> p = new WBLeftistHeapPriorityQueue();
        for(Tuple2<Character, Integer> r : dic.keysValues()){
            p.enqueue(new WLeafTree<>(r._1(), r._2()));
        }
        return p;
    }

    // Exercise 2.b  (2.50 puntos)
    public static WLeafTree<Character> huffmanTree(String s) {
    	// s debe tener dos caracteres distintos. Si no, excepcion
        Dictionary<Character,Integer> dic = weights(s);
        if(dic.size()<=1){
            throw new HuffmanException("Tiene que tener al menos 2 caracteres");
        }
        //Ordeno los elementos
        PriorityQueue<WLeafTree<Character>> p = huffmanLeaves(s);
        //Inserto el primer elemento que es el menor
        WLeafTree<Character> wi = p.first();
        //lo elimino de la cola, porque ya lo inserte
        p.dequeue();
        //Mientras no sea vacio, tengo que seguir metiendo
        while(!p.isEmpty()){
            //cojo el segundo elemento más pequeño
            WLeafTree<Character> wd = p.first();
            p.dequeue();
            //Meto el árbol de nuevo en la cola
            p.enqueue(new WLeafTree<>(wi, wd));
            //Lo inserto en wi y vuelvo a repetir con los demás elementos
            wi = p.first();
            p.dequeue();
        }
    	return wi;
    }

    // Exercise 3.a (1 punto)
    public static Dictionary<Character, List<Integer>> joinDics(Dictionary<Character, List<Integer>> d1, Dictionary<Character, List<Integer>> d2) {
        Dictionary<Character, List<Integer>> t = new AVLDictionary<>();
        for(Tuple2<Character, List<Integer>> t1 : d1.keysValues()){
            t.insert(t1._1(), t1._2());
        }
        for(Tuple2<Character, List<Integer>> t1 : d2.keysValues()){
            t.insert(t1._1(), t1._2());
        }
    	return t;
    }

    // Exercise 3.b  (1 punto)
    public static Dictionary<Character, List<Integer>> prefixWith(int i, Dictionary<Character, List<Integer>> d) {
        Dictionary<Character, List<Integer>> t = new AVLDictionary<>();
        for(Tuple2<Character, List<Integer>> s : d.keysValues()){
            List<Integer> lista = new ArrayList<>();
            lista.append(i);
            for(int r : s._2()){
                lista.append(r);
            }
            t.insert(s._1(), lista);
        }
    	return t;
    }

    // Exercise 3.c  (1.50 puntos)
    public static Dictionary<Character, List<Integer>> huffmanCode(WLeafTree<Character> ht) {
        Dictionary<Character, List<Integer>> dic = new AVLDictionary<>();
        //Compruebo si ht es hoja, en ese caso introduzco la hoja y la lista
        if(ht.isLeaf()){
            List<Integer> lista = new ArrayList<>();
            dic.insert(ht.elem(), lista);
        }else{//Si no es hoja, debo ir por la izquierda y la derecha
            Dictionary<Character, List<Integer>> d1 = huffmanCode(ht.leftChild());
            Dictionary<Character, List<Integer>> d2 = huffmanCode(ht.rightChild());
            d1 = prefixWith(0, d1);
            d2 = prefixWith(1, d2);
            dic = joinDics(d1,d2);
        }
    	return dic;
    }

    // Exercise 4  (0.50 puntos)
    public static List<Integer> encode(String s, Dictionary<Character, List<Integer>> hc) {
        List<Integer> lista = new ArrayList<>();
        for(char c : s.toCharArray()){
            if(!hc.isDefinedAt(c)){
                throw new HuffmanException("No existe este caracter");
            }
            for(int n : hc.valueOf(c)){
                lista.append(n);
            }
        }
    	return lista;
    }

    // Exercise 5  (2 puntos)
    public static String decode(List<Integer> bits, WLeafTree<Character> ht) {
        StringBuilder sb = new StringBuilder();
        WLeafTree<Character> current = ht;
        for (int n : bits) {
            if (n == 0)
                current = current.leftChild();
            else
                current = current.rightChild();
            if (current.isLeaf()) {
                sb.append(current.elem());
                current = ht;
            }
        }
        return sb.toString();
    }
}
