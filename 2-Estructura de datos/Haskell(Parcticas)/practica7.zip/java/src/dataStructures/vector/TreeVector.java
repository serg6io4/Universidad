/******************************************************************************
 * Student's name:
 * Student's group:
 * Data Structures. Grado en Informática. UMA.
******************************************************************************/

package dataStructures.vector;

import dataStructures.list.ArrayList;
import dataStructures.list.List;

import java.util.Iterator;

public class TreeVector<T> {

    private int size;
    private Tree<T> root;

    private interface Tree<E> {
        E get(int index);

        void set(int index, E x);

        List<E> toList();
    }

    private static class Leaf<E> implements Tree<E> {
        private E value;

        public Leaf(E x) {
            value = x;
        }

        @Override
        public E get(int i) {
            return this.value;
        }

        @Override
        public void set(int i, E x) {
        	this.value = x;
        }

        @Override
        public List<E> toList() {
            ArrayList lista = new ArrayList<>();
            lista.append(value);
            return lista;
        }
    }

    private static class Node<E> implements Tree<E> {
        private Tree<E> left;
        private Tree<E> right;

        public Node(Tree<E> l, Tree<E> r) {
            left = l;
            right = r;
        }

        @Override
        public E get(int i) {
            if (i % 2 == 0) {
                return left.get(i / 2);
            } else{
                return right.get(i / 2);
            }
        }

        @Override
        public void set(int i, E x) {
            if (i % 2 == 0) {
                 left.set((i / 2), x);
            } else{
                 right.set((i / 2), x);
            }
        }

        @Override
        public List<E> toList() {
            return intercalate(left.toList(), right.toList());
        }
    }


    public TreeVector(int n, T value) {
    	if(n < 0){
            throw new VectorException("No valores negativos");
        }
        size = (int) Math.pow(2, n);
        root = creaArbol(n, value);
    }

    private Tree<T> creaArbol(int n, T value) {
        if(n==0){
            return new Leaf<>(value);
        }else{
            Tree<T>left = (creaArbol((n-1), value));
            Tree<T>right = (creaArbol((n-1),value));
            return new Node<>(left,right);
        }
    }

    public int size() {
        return size;
    }

    public T get(int i) {
        if((i < 0) || (i > this.size)){
            throw new VectorException("Fuera de rango");
        }
        return root.get(i);
    }

    public void set(int i, T x) {
        if((i < 0) || (i > this.size)){
            throw new VectorException("Fuera de rango");
        }
    	root.set(i, x);
    }

    public List<T> toList() {
        return root.toList();
    }

    protected static <E> List<E> intercalate(List<E> xs, List<E> ys) {
        ArrayList lista = new ArrayList<>();
        Iterator ixs = xs.iterator();
        Iterator iys = ys.iterator();
        while (ixs.hasNext() && iys.hasNext()){
            lista.append(ixs.next());
            lista.append(iys.next());
        }

        return lista;
    }

    static protected boolean isPowerOfTwo(int n) {
    	//to do
        return false;
    }

    public static <E> TreeVector<E> fromList(List<E> l) {
    	//to do
        return null;
    }
}
