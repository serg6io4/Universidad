INSERT INTO `Usuario` VALUES ('antonio','García',NULL,'antonio',NULL,'Antonio');
INSERT INTO `Contacto` VALUES (1,'fulanito@uma.es','Fulanito','123456789','antonio'),(2,'menganito@uma.es','Menganito','987654321','antonio');
DELETE FROM `hibernate_sequence`;
INSERT INTO `hibernate_sequence` VALUES (3);
