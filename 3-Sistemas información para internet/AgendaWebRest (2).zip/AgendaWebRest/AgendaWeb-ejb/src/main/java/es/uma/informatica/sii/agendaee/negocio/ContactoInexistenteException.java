package es.uma.informatica.sii.agendaee.negocio;

public class ContactoInexistenteException extends AgendaException {

}
