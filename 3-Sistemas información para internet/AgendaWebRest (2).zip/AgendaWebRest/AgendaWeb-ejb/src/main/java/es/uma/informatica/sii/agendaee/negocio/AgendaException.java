
package es.uma.informatica.sii.agendaee.negocio;

/**
 *
 * @author francis
 */
public class AgendaException extends Exception {

    public AgendaException() {
    }

    public AgendaException(String msg) {
        super(msg);
    }
}
