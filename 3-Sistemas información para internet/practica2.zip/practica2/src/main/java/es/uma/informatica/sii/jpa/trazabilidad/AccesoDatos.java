package es.uma.informatica.sii.jpa.trazabilidad;

import java.io.Closeable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 * Esta clase servirá para centralizar todas las operaciones relacionadas con la 
 * gestión de los datos relativos a los productos y sus lotes. 
 * Recuerda que las operaciones que modifiquen la base de datos deben ejecutarse dentro
 * de una transacción.
 * @author francis
 *
 */
public class AccesoDatos implements Closeable {
	
	private EntityManagerFactory emf;
	private EntityManager em;
	
	/**
	 * Constructor por defecto. Crea un contexto de persistencia.
	 */
	public AccesoDatos() {
		emf = Persistence.createEntityManagerFactory("jpa-trazabilidad");
		em = emf.createEntityManager();
	}
	
	/**
	 * Cierra el contexto de persistencia.
	 */
	@Override
	public void close() {
		em.close();
		emf.close();
	}
	
	/**
	 * Devuelve la lista de todos los productos que hay en la base de datos.
	 * @return Lista de proudctos
	 */
	
	public List<Producto> getListaProductos() {
		em.getTransaction().begin();
		TypedQuery<Producto> query = em.createQuery("SELECT p FROM Producto p", Producto.class);
		List<Producto> productos = query.getResultList();
		em.getTransaction().commit();
		return productos;
		
	}
	
	
	/**
	 * Elimina un producto y todos sus lotes asociados en la base de datos.
	 * El producto debe encontrarse en el contexto de persistencia.
	 * @param producto El producto a eliminar.
	 */
	public void eliminarProducto(Producto producto) {
		em.getTransaction().begin();
		for (int i = 0; i < producto.getLotes().size(); i++) {
			em.remove(producto.getLotes().get(i));
		}
		em.remove(producto);
		em.getTransaction().commit();
	}
	
	/**
	 * Introduce un producto en la base de datos. 
	 * Este producto debe tener una lista de lotes vacía y no puede
	 * existir en el contexto de persistencia.
	 * @param producto Producto a introducir en la base de datos.
	 */
	
	public void crearProducto(Producto producto) {
		em.getTransaction().begin();
		em.persist(producto);
		em.getTransaction().commit();
	}
	
	/**
	 * Añade un nuevo lote a un producto concreto.
	 * @param producto Producto al que se le añade el lote.
	 * @param lote Lote que se debe añadir. Este lote debe ser de nueva creación.
	 */
	public void aniadirLoteAProducto(Producto producto, Lote lote) {
		em.getTransaction().begin();
		em.persist(lote);
		producto.getLotes().add(lote);
		em.getTransaction().commit();
	}
	
	/**
	 * Elimina un lote de un producto y de la base de datos.
	 * @param producto Producto al que hay que quitarle un lote.
	 * @param lote Lote que se debe eliminar del producto. Este lote debe
	 * encontrarse asociado al producto.
	 */
	public void eliminarLoteDeProducto(Producto producto, Lote lote) {
		em.getTransaction().begin();
		producto.getLotes().remove(lote);
		em.remove(lote);
		em.getTransaction().commit();
	}
	
}
