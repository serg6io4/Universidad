package es.uma.informatica.sii.jpa.trazabilidad;

import java.util.List;
import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name="PRODUCTO")

public class Producto {
	
	private static final long serialVersionUID= 1L;
	@Id @GeneratedValue(strategy=GenerationType.AUTO)@Column(name="CODIGO_BARRAS")
	private String codigoBarras;
	@Column(name="NOMBRE")
	private String nombre;
	@Column(name="DESCRIPCION")
	private String descripcion;
	@OneToMany(cascade={CascadeType.PERSIST,CascadeType.REMOVE})
	private List<Lote> lotes;
	
	public Producto(String codigoBarras, String nombre, String descripcion) {
		super();
		this.codigoBarras = codigoBarras;
		this.nombre = nombre;
		this.descripcion = descripcion;
	}
	
	public Producto() {
		super();
	}
	
	public String getCodigoBarras() {
		return codigoBarras;
	}
	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public List<Lote> getLotes() {
		return lotes;
	}
	public void setLotes(List<Lote> lotes) {
		this.lotes = lotes;
	}

	@Override
	public int hashCode() {
		return Objects.hash(codigoBarras);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Producto other = (Producto) obj;
		return Objects.equals(codigoBarras, other.codigoBarras);
	}

	@Override
	public String toString() {
		return "Producto [codigoBarras=" + codigoBarras + ", nombre=" + nombre + ", descripcion=" + descripcion + "]";
	}
	
	
	

}
