////////////////////////////////////////////////////////////////////////////////////////////
// ALUMNO:Sergio Camacho Mar�n y Juan Antonio Dom�nguez Arcas
// GRUPO:2C
////////////////////////////////////////////////////////////////////////////////////////////

public class OrdenacionRapida extends Ordenacion {
  
	public static <T extends Comparable<? super T>> void ordenar(T v[]) {
	    ordRapidaRec(v, 0, v.length-1);
	}

	// Debe ordenar ascendentemente los primeros @n elementos del vector @v con 
	// una implementaci�n recursiva del m�todo de ordenaci�n r�pida.	
	public static <T extends Comparable<? super T>> void ordRapidaRec(T v[], int izq, int der) {
		//A completar por el alumno
	     if(der>izq) {
	    	int pivote = partir(v,v[izq],izq,der);//Le paso el primer valor del vector como pivote
	    	ordRapidaRec(v, izq, pivote-1);//Ordeno por la izquierda
	    	ordRapidaRec(v, pivote+1, der);//Ordeno por la derecha
	    }
	}
	   
   public static <T extends Comparable<? super T>> int partir(T v[], T pivote, int izq, int der) {
	    // A completar por el alumno
	   int i = izq;
	   int d = der;
	   while(i<d) {//Compruebo que la posici�n de los arrays no est� mal
		   /*Compruebo de derecha a izquierda para saber si el primer elemento que le he pasado como
		    * pivote es el menor o por la derecha hab�a otro*/
		   while(v[d].compareTo(pivote)>0) {
			   d--;
		   }
		   //Compruebo que el pivote seal el menor por la izquierda, si lo es aumento la i
		   while(v[i].compareTo(pivote)<0) {
			   i++;
		   }
		   if(i<d) {
			   if(v[i].compareTo(v[d])==0) {//Compruebo que si el valor de es el mismo paso a 
				   							//la siguiente i y repito el bucle
				   i++;
			   }else {//Intercambio los valores en caso de que la izq sea mayor que la derecha
				   Ordenacion.intercambiar(v, i, d);
			   }
		   }
	   }
	    return d;    	
   }

	// Peque�os ejemplos para pruebas iniciales.
	public static void main (String args[]) {
	
		// Un vector de enteros
		Integer vEnt[] = {3,0,2,7,3,4,6,9,1};
		ordenar(vEnt);
		System.out.println(vectorAString(vEnt));

		// Un vector de caracteres
		Character vCar[] = {'d','c','v','b'};
		ordenar(vCar);
		System.out.println(vectorAString(vCar));

	}	
    
}
