////////////////////////////////////////////////////////////////////////////////////////////
// ALUMNO:Sergio Camacho Mar�n y Juan Antonio Dom�nguez Arcas 
// GRUPO:2C
////////////////////////////////////////////////////////////////////////////////////////////

public class OrdenacionRapidaBarajada extends OrdenacionRapida {
	
	// Implementaci�n de QuickSort con reordenaci�n aleatoria inicial (para comparar tiempos experimentalmente)
	public static <T extends Comparable<? super T>> void ordenar(T v[]) {
		// A completar por el alumno
		barajar(v);
		OrdenacionRapida.ordRapidaRec(v, 0, v.length-1);
    }

	// reordena aleatoriamente los datos de un vector
    private static <T> void barajar(T v[]) {
    	// A completar or el alumno
    	
    	for(int i = 0;i<v.length;i++) {
    		int aleatorio = Ordenacion.aleat.nextInt(v.length);
    		Ordenacion.intercambiar(v, i, aleatorio);
    	}
    }	
 

}
