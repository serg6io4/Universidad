////////////////////////////////////////////////////////////////////////////////////////////
// ALUMNO:Sergio Camacho Mar�n y Juan Antonio Dom�nguez Arcas 
// GRUPO:2C
////////////////////////////////////////////////////////////////////////////////////////////

import java.util.Scanner;

public final class BuscaElem{
	
	public static <T extends Comparable<? super T>> T kesimo(T v[], int k) {
		return kesimoRec(v,0,v.length-1,k);//Llamo a K-�simo recursivo
	}

	public static <T extends Comparable<? super T>> T kesimoRec(T v[], int izq, int der, int k) {
		// A IMPLEMENTAR POR EL ALUMNO
		//if(izq>der)return v[der]; El �nico K-�simo que habr� ser� uno de los dos
		int s = OrdenacionRapida.partir(v, v[izq], izq, der);
		//Llamo a partir para saber el orden en el que queda el pivote 
		if(k+izq==s) {//El pivote en alg�n momento tendr� que coincidir con el k-�simo por pantalla
			return v[s];
		}else if(k+izq<s){//Si el k-�simo es m�s peque�o que el pivote voy por la izquierda
			return kesimoRec(v, izq, s-1, k);
		}else {//Si el k-�simo es m�s grande que el pivote voy por la derecha pero recortando el array,
				//contando las posiciones desde la que estaba menos lo recorrido -1
			return kesimoRec(v, s+1, der, k+izq-s-1);
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int maxvector;
		int i,k;
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Introduce el numero de posiciones del vector: ");
		maxvector=sc.nextInt();
		Integer v[]=new Integer[maxvector];

		System.out.print("Introduce "+maxvector+" enteros separados por espacios: ");
		for (i=0;i<maxvector;i++) v[i]=sc.nextInt();
		System.out.print("Introduce la posicion k deseada (de 1-"+maxvector+"): ");k=sc.nextInt();
		Integer elem=kesimo(v,k-1);
		System.out.print("El elemento "+k+"-esimo es: "+elem);
	}

}
