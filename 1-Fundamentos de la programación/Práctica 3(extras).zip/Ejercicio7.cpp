#include <iostream>
using namespace std;

int main(){

    double operando1, operando2;
    char operacion;

    cout<<"Operacion: ";
    cin>>operacion;

    while(operacion!='&'){

        switch(operacion){
        case '+':
            cout<<"Operando 1: ";
            cin>>operando1;
            cout<<"Operando 2: ";
            cin>>operando2;
            cout<<"Resultado: "<<operando1+operando2;
        case '-':
            cout<<"Operando 1: ";
            cin>>operando1;
            cout<<"Operando 2: ";
            cin>>operando2;
            cout<<"Resultado: "<<operando1-operando2;
        case '*':
            cout<<"Operando 1: ";
            cin>>operando1;
            cout<<"Operando 2: ";
            cin>>operando2;
            cout<<"Resultado: "<<operando1*operando2;
        case '/':
            cout<<"Operando 1: ";
            cin>>operando1;
            cout<<"Operando 2: ";
            cin>>operando2;
            if(operando2==0){
                throw "No puedes dividir entre 0";
            }
            cout<<"Resultado: "<<operando1/operando2;
        default:
            throw "Operacion equivocada";
        }
    }

return 0;
}

