#include <iostream>
using namespace std;

int main(){
    double paso=0;
    double numerador = 2;
    double denominador = 3;
    int i = 0;
    int n;
    double pi=4;
    cout<<"Introduzca un n�mero para los decimales de pi: ";
    cin>>n;
    while(i<n){
       pi=pi*(numerador/denominador);
       paso = numerador;
       numerador=denominador+1;
       denominador=paso+1;
       i++;
    }
    cout<<"El resultado es: "<< pi;


return 0;
}
