#include <iostream>
using namespace std;

int main(){

    double operando1, operando2;
    char operacion;

    cout<<"Operacion: ";
    cin>>operacion;

    while(operacion!='&'){

        switch(operacion){
        case '+':
            cout<<"Operando 1: ";
            cin>>operando1;
            cout<<"Operando 2: ";
            cin>>operando2;
            cout<<"Resultado: "<<operando1+operando2;
        case '-':
            cout<<"Operando 1: ";
            cin>>operando1;
            cout<<"Operando 2: ";
            cin>>operando2;
            cout<<"Resultado: "<<operando1-operando2;
        case '*':
            cout<<"Operando 1: ";
            cin>>operando1;
            cout<<"Operando 2: ";
            cin>>operando2;
            cout<<"Resultado: "<<operando1*operando2;
        case '/':
            cout<<"Operando 1: ";
            cin>>operando1;
            cout<<"Operando 2: ";
            cin>>operando2;
            while(operando2==0){
               cout<<"No se puede dividir entre 0, ponga un denominador mayor que 0: ";
               cin>>operando2;
            }
            cout<<"Resultado: "<<operando1/operando2;
        }

        cout<<"FIN DEL PROGRAMA";
    }

return 0;
}
