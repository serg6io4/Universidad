#include <iostream>
using namespace std;

void leerDatos(int& a, int& b){

     cout<<"Dime un numero: ";
     cin>>a;
     cout<<"Dime un numero: ";
     cin>>b;
}

int suma(int n){
    int resultado=0;
    for(int i=1;i<n;i++){
        if(n%i==0){
            resultado+=i;
        }
    }
return resultado;
}
bool sonAmigos(int a, int b){
    return suma(a)==suma(b);
}
/*void imprimirParejas(int n, int m){
 for(int i = n; i <= m; i++){
  for(int j = i; j <= m; j++){
   cout << i << " y "<< j;
   if(sonAmigos(i, j)){
    cout << " son amigos."<< endl;
    cout<<" Suma de divisores de "<<i<<" es "<<SumaDivisores(i)<<" = "<<j<<endl;
    cout<<" Suma de divisores de "<<j<<" es "<<SumaDivisores(j)<<" = "<<j<<endl;
   }else{
    cout << " no son amigos." << endl;
   }
  }
 }
}*/
int main(){
    int primero, segundo;
    leerDatos(primero, segundo);
    if(sonAmigos(primero,segundo)){
        cout<<"Son amigos";
    }else{
        cout<<"No son amigos";
    }

return 0;
}
