#include <iostream>
using namespace std;

void leerDatos(int& x){
 do{
  cout << "Introduce altura de la pir�mide: ";
  cin >> x;
 }while( x < 1);
}

void dibujarFila(int x, int i){
 for(unsigned j = 1; j <= (x-i); j++){
  cout << "  ";
 }
 for(unsigned j = 1; j<= i; j++){
  cout << " *  ";
 }

}

void dibujarPiramide (int x){
 for(unsigned i = 1; i <= x; i++){
  dibujarFila(x, i);
  cout << endl;
 }
}

void dibujarPiramideInv (int x){
 for(unsigned i= 1; i < x; i++){
  for(unsigned j = 1; j <= i ; j++){
   cout << "  ";
  }
  for(unsigned j = 1; j <= (x - i); j++){
   cout << " *  ";
  }

  cout << endl;
 }
}

int main() {
 int x;
 leerDatos(x);
 dibujarPiramide(x);
 dibujarPiramideInv(x);
 return 0;
}
