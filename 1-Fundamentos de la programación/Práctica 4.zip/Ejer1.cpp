#include <iostream>
using namespace std;

int leerDatos(){
    int n;
    cout<<"Numero de filas: ";
    cin>>n;
return n;
}
void escribeEspacios(int b){
    int i=b;
    while(i>0){
        cout<<" ";
        i--;
    }
}
void escribirAscendente(int b){
    for(int i=1;i<=b;i++){
        cout<<i;
    }
}
void escribirDescendente(int b){
    for(int i=b-1;i>0; i--){
        cout<<i;
    }
}
void escribirLinea(int total, int fila){
    escribeEspacios(total-fila);
    escribirAscendente(fila);
    escribirDescendente(fila);
    cout<<endl;
}
void escribirPiramide(int nf){
    for(int i=1; i<=nf;i++){
        escribirLinea(nf, i);
    }
}
int main(){

    int fila = leerDatos();
    escribirPiramide(fila);

return 0;
}
