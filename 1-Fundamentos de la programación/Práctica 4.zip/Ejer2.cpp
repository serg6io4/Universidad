#include <iostream>
using namespace std;

int leerDatos(){
    int n;
    cout<<"Introduce un numero: ";
    cin>>n;
    return n;
}
bool esPrimo(int n){
 bool primo = true ;
 int i = 2;
 while((primo) && (i <= int(n/2))){
    if(n != i){
        if(n%i == 0){
            primo = false;
        }
    }
  i++;
 }
 return primo;
}
void imprimePrimo(int pr){
    for(int i=1; i<=pr; i++){
        if(esPrimo(i)){
            cout<<i<<",";
        }
    }
}
int main(){
    int p;
    p = leerDatos();
    imprimePrimo(p);

return 0;
}
