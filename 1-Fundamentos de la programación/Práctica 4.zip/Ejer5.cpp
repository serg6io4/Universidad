#include <iostream>
using namespace std;

int LeerNFilas(){
 int filas;
 do{
  cout << "Introduce el n�mero de filas de la pir�mide: ";
  cin >> filas;
 }while(filas < 1);
 return filas;
}

void PiramideDigitos(int filas){
 for(unsigned i= 1; i <= filas; i++){
  for(unsigned j = 1; j <= (filas - i); j++){
   cout << " ";
  }
  for(unsigned j= i; j <= (i + i -1); j++){
   cout << j%10;
  }
  for(unsigned h = (i + i -2); h >= i; h-- ){
   cout << h%10;
  }

  cout << endl;
 }
}


int main() {
 int filas;
 cout << "Practica 4. Pir�mide de d�gitos" << endl;
 filas= LeerNFilas();
 PiramideDigitos(filas);
 return 0;
}
