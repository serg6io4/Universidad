#include <iostream>
using namespace std;
//No puede sumar  1 y 3000000000, porque desborda el valor de int.
int main(){

    int a, b;
    cout<< "Solo sumo dos n�meros"<<endl;
    cout<<"Introduce dos numeros: "<<endl;
    cin>>a>>b;

    a=a+b;
    cout << "La suma de los numeros es: "<<a;
return 0;
}
