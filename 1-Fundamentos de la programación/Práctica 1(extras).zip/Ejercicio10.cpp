#include <iostream>
using namespace std;

int main(){

    int segundos, minutos, hora, dias, semanas;
    cout<<"Introduzca los segundos: "<<endl;
    cin>>segundos;

    minutos=segundos/60;
    hora=minutos/60;
    dias=hora/12;
    semanas=dias/7;
    segundos=segundos-((minutos)+(hora*3600)+(dias*12)+(semanas*7));

    cout<<"Semanas: "<<semanas;
    cout<<"; Dias: "<<dias;
    cout<<"; Horas: "<<hora;
    cout<<"; Minutos: "<<minutos-(hora*60);
    cout<<"; Segundos: "<<segundos;

}
