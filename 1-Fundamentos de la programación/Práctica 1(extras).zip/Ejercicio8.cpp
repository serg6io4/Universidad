#include <iostream>
using namespace std;

int main(){

    char a, b, c, d;
    cout <<"Escribe cuatro letras min�sculas: "<< endl;
    cin>>a>>b>>c>>d;

    a=a-32;
    b=b-32;
    c=c-32;
    d=d-32;

    cout <<a<<b<<c<<d;

return 0;
}
