#include <iostream>
using namespace std;

const float teoria=0.7;
const float practico=0.3;

int main(){

        float nota, nota1;
        cout << "Introduce la nota teorica y la pr�ctica: "<<endl;
        cin>>nota>>nota1;

        nota=nota*teoria;
        nota1=nota1*practico;
        cout<<"Su nota es: "<<nota+nota1;

return 0;
}
