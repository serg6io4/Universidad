#include <iostream>
using namespace std;
int main()
{
 int a=6, b=14;
 int auxiliar;
 cout << �a vale � << a << � y b vale � << b << endl;
 // �Qu� hacen estas tres sentencias?
    auxiliar = a;
    a = b;
    b = auxiliar;

 cout << �a vale � << a << � y b vale � << b << endl;

 return 0;
}
//Las tres sentencias realizan un intercambio de referencias entre a y b
//Por lo tanto a vale b y b vale a.

 /*a = a + b;
 b = a - b;
 a = a - b;*/
 //Realiza la misma operaci�n que el anterior pero sin la necesidad de un auxiliar
 //Te ahorra una variable que declarar.
