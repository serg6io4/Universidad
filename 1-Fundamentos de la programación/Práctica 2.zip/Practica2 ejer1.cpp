#include <iostream>
using namespace std;

int main(){

    int x;
    cout<<"Introduce un n�mero entero: ";
    cin>>x;
    if(x<0){
        cout<<"Es negativo"<<endl;
    }else{
        cout<<"Es positivo"<<endl;
    }

return 0;
}
