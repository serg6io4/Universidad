#include <iostream>
using namespace std;

int main(){

    char c;
    cout<<"Introduce un car�cter: ";
    cin>>c;

    if (((c>=65)&&(c<=90))||((c>=97)&&(c<=120))){
        cout<<"Es una letra.";
    }else if((c=='.')){
        cout<<"Es un punto";
    }else{
        cout<<"Error";
    }



return 0;
}
