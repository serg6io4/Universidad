#include <iostream>
using namespace std;

int main(){

    int x, y, z;
    cout<<"Introduce tres n�meros enteros: "<<endl;
    cin>>x>>y>>z;

    if((x>y)&&(x>z)){
        cout<<"El mayor estricto es: "<<x;
    }else if((y>x)&&(y>z)){
        cout<<"El mayor estricto es: "<<y;
    }else if((z>x)&&(z>y)){
        cout<<"El mayor estricto es: "<<z;
    }else{
        cout<<"No hay mayor estricto";
    }
return 0;
}
