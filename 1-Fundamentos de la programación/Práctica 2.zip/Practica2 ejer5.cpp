#include <iostream>
using namespace std;

const int producto = 100;
const float IVA = 0.12;
const float descuento = 0.05;

int main(){

    int x;
    double y;
    cout<<"Introduce el numero del producto: ";
    cin>>x;

    y = x*producto +(x*producto*IVA);
    if(y<=300){
        cout<<"Numero de unidades adquiridas: "<<x<<endl;
        cout<<"El precio total a pagar: "<<y<<" euros"<<endl;
    }else{
        cout<<"Numero de unidades adquiridas: "<<x<<endl;
        y = y - (y*descuento);
        cout<<"Se aplica un descuento del 5%"<<endl;
        cout<<"El precio total a pagar: "<<y<<" euros"<<endl;
    }

return 0;
}
