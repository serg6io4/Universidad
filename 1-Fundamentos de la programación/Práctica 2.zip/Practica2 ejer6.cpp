#include <iostream>
using namespace std;

const float tarifa1 = 0.50;
const float tarifa2 = 0.35;
const float tarifaresto = 0.25;
const int gastofijo = 1;

int main(){
    double x;
    cout<<"Introduce un numero de KW consumidos: ";
    cin>>x;

    if(x<=100){
      x = tarifa1*x + gastofijo;
      cout<<"El importe a pagar es: "<<x;
    }else if(x>=100 && x<=150){
        x=tarifa1*100 + gastofijo+ tarifa2*(x-100);
        cout<<"El importe a pagar es: "<<x;
    }else{
        x=tarifa1*100 + gastofijo+ tarifa2*150+ tarifaresto*(x-250);
        cout<<"El importe a pagar es: "<<x;
    }
return 0;
}
