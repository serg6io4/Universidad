#include <iostream>

using namespace std;

unsigned sumaNaturales(unsigned n){
    if(n<0) return 0;
    if(n>1) return n+sumaNaturales(n-1);
}


int main()
{
    int n;
   cout<< " Suma de naturales segun tu numero: ";
   cin>> n;
   cout<< "Tu suma es: "<< sumaNaturales(n)<<endl;
}
