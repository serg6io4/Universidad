/*
    *APELLIDOS, NOMBRE: ESQUIVEL MARIN, MANUEL
    *TITULACION: GRADO EN INGENIERIA DEL SOFTWARE
    *GRUPO: B
    *FECHA: 24/11/2017
    *Relacion Tema 3. Descomposicion En Factores Primos.
*/

#include <iostream>
using namespace std;

void leerDatos(int& n){
    cout << "...Descomposicion en Factores Primos de un Numero Natural..." << endl << endl;
    cout << "Introduzca el numero (>0): ";
    cin >> n;

    while(n<=0){
        cout << "Vuelva a intentarlo: ";
        cin >> n;
    }
}

//No hay que utilizarlo en esta implementacion, pero se podria utilizar en otra
bool esPrimo(int n){
    unsigned d = 2;
    bool esPrimo = true; //Presupongo que va a ser primo

    if (n == 1) esPrimo = false; //1 no es primo

    while((d < n) && esPrimo){ //Voy a iterar desde 2 hasta antes de n, ya que solo puede ser dividido por 1 y si mismo
        if (n % d == 0) esPrimo = false;
        d++;
    }

    return esPrimo;
}

int nuevoPrimo(int n, int primo){
    int nuevoPrimo = primo; //Si no se cumple la condicion del while, devolvere el mismo al final

    while ((n % nuevoPrimo != 0) && (n >= nuevoPrimo)){ //Mientras n NO sea divisible por un primo y n sea mayor o igual, lo incremento
        nuevoPrimo++;
        //Es redundante este bucle, ya que si 2 o 3 no divide a n, 4,6,8,9 tampoco
        while (!esPrimo(nuevoPrimo)) nuevoPrimo++; //No me interesan los que no son primos (entre 3 y 5, entre 7 y 11) .. (2,3,5,7,11)
    }

    return nuevoPrimo;
}

void descomposicionEnFactoresPrimos(int n){
    int primo = 2; //Elijo como primer primo el 2
    int nuevoPrim; //Variable para almacenar el nuevo primo que sea divisible por n

    if (esPrimo(n)){ //Si n es primo, realmente no tengo que seguir (n y 1). Me ahorro N operaciones de incrementar nuevoPrim hasta encontrarse a si mismo
        cout << "Factores Primos de " << n << " = " << n << endl;
    } else{ //Si n no es primo
        nuevoPrim = nuevoPrimo(n, primo); //Me aseguro que 2 en adelante dividan a n
        cout << "Factores Primos de " << n << " = ";
        if (n == 1) cout << "Ninguno, 1 NO es Primo NI Integrante";
        while ((n % nuevoPrim == 0) && (n >= nuevoPrim)){ //Mientras los primos dividan a n y n sea mayor o igual, ya que acabo cuando: 24,12,6,3, 1 -- 2,2,2,3 ((1) < (3))
            cout << nuevoPrim << " "; //Tenemos el primero asegurado y mostraremos los restantes despues
            n = n / nuevoPrim; //Actualizo el valor de n para seguir descomponiendo (24 - 12 - 6 ...)
            nuevoPrim = nuevoPrimo(n, nuevoPrim); //Actualizo mi primo asegurandome que divida a n
        }
        //Cuando he acabado n == 1 y nuevoPrim == 3 (24)
        cout << endl;
    }
}

int main(){
    int n;

    leerDatos(n);
    descomposicionEnFactoresPrimos(n);

    return 0;
}
