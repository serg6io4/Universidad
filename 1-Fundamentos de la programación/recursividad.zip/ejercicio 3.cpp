#include <iostream>

using namespace std;

unsigned producto(unsigned x, unsigned y){

    unsigned resultado;
    if(y==0){
        resultado=0;
    }
    if(y!=0){
        resultado=x+producto(x,y-1);
    }
    return resultado;
}


int main()
{
    unsigned x, y;
    cout<<"Introduzca un numero: ";
    cin>>x;
    cout<<"Introduzca otro numero: ";
    cin>>y;

    cout<<"El resultado es: "<< producto(x,y)<<endl;
}
