#include <iostream>

using namespace std;

unsigned potencia(unsigned x, unsigned n){

      float resultado;

      if(n==0){
        resultado=1;
      }else{
         resultado= x*potencia(x,n-1);
      }
      return resultado;
}

int main()
{

      unsigned x, n;
      cout<<"Introduzca x: ";
      cin>>x;
      cout<<"Introduzca n: ";
      cin>>n;
      cout<<"La potencia de " << x<< " es: "<< potencia(x,n)<<endl;

}
