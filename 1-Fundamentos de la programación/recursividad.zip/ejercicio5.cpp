#include <iostream>

using namespace std;

bool esPrimoRec (unsigned num, unsigned divisor){
      unsigned resultado;
      if(divisor>num){
        resultado=true;
      }else if(num%divisor==0){
        resultado=false;

      }else{
        resultado=esPrimoRec(num, divisor+1);
        }
    return resultado;
}

int main()
{
    unsigned num, divisor;

    cout<<"Introduzca n: ";
    cin>>num;
    cout<<esPrimoRec(num,divisor)<<endl;
}
//IMCOMPLETO.
