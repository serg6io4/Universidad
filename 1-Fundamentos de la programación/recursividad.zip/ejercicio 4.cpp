#include <iostream>

using namespace std;

void inverso (unsigned n){

   unsigned resto;
   if(n<10){
    cout<<n;
   }else{
   cout<<n%10;
   inverso(n/10);
   }
}

int main()
{
   unsigned n;
   cin>>n;
   inverso(n);
}
