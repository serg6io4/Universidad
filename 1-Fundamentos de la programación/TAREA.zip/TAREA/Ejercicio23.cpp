#include <iostream>
using namespace std;


int main(){
    int fibonacci=0;
    int fibonacc=1;
    int result=0;
    int n=0;
    int i=0;

    cout<<"Introduce un n�mero Quintana: ";//Es un amigo que prueba mi c�digo
    cin>>n;
    n=n-3;//el menos 3, lo hago porque tengo dos fibonacci calculados + el n-�simo tambi�n.
    while(i<=n){
    result= fibonacci+fibonacc;
    fibonacci=fibonacc;
    fibonacc=result;
    i++;
    }
    cout<<result;

return 0;
}
