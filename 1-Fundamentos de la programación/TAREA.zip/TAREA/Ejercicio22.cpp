#include <iostream>
using namespace std;

int main() {
	bool enc = false;
	char c;


	cout << "Introduzca una sucesion de caracteres terminada en '.': ";
	cin >> c;
	do{
		if(c=='a'){
			cin>>c;

			if(c=='b'){
				cin>>c;
				if(c=='c'){
					enc=true;
					c='.';
				}
			}
		}else{

			cin>>c;
		}
	}while(c!='.');

	if(enc){
		cout << "La cadena 'abc' se encuentra en la sucesi�n de caracteres.";
	}else{
		cout << "La cadena 'abc' no se encuentra en la sucesi�n de caracteres.";
	}
	return 0;
}
