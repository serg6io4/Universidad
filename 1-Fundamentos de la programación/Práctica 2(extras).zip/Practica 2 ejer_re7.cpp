#include <iostream>
using namespace std;

int main(){

    int x;
    cout<<"Introduce el ordinal del mes: ";
    cin>>x;
    if(x<1 || x>13){
        cout<<"Error en el mes";
    }else{
        switch(x){
        case 1:
            cout<<"Este mes tiene 31 dias"<<endl;
            break;
        case 2:
            cout<<"Este mes tiene 28 dias"<<endl;
            break;
        case 3:
            cout<<"Este mes tiene 31 dias"<<endl;
            break;
        case 4:
            cout<<"Este mes tiene 30 dias"<<endl;
            break;
        case 5:
            cout<<"Este mes tiene 31 dias"<<endl;
            break;
        case 6:
            cout<<"Este mes tiene 30 dias"<<endl;
            break;
        case 7:
            cout<<"Este mes tiene 31 dias"<<endl;
            break;
        case 8:
            cout<<"Este mes tiene 31 dias"<<endl;
            break;
        case 9:
            cout<<"Este mes tiene 30 dias"<<endl;
            break;
        case 10:
            cout<<"Este mes tiene 31 dias"<<endl;
            break;
        case 11:
            cout<<"Este mes tiene 30 dias"<<endl;
            break;
        case 12:
            cout<<"Este mes tiene 31 dias"<<endl;
            break;
        }
    }

return 0;
}
