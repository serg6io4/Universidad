#include <iostream>
using namespace std;

int main(){

    int x, y, z;
    cout<<"Introduce un serial de 4 digitos(el primero distinto de 0): ";
    cin>>x;
    y=x/1000;
    z=(x-y*1000)/10;

    if((x/100)==0){
        cout<<"ERROR: CODIGO INVALIDO (no tiene 4 digitos)"<<endl;
    }else if((z/y)!=(x/1000)){
        cout<<"ERROR: CODIGO INVALIDO (digito de control erroneo)"<<endl;
    }else{
        cout<<"PROVINCIA        "<<y<<endl;
        cout<<"NUMERO DE OPERACION        "<<z<<endl;
        x=x-(y*1000)-(z*10);
        cout<<"DIGITO DE CONTROL        "<<x<<endl;
    }
return 0;
}

