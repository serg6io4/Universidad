#include <iostream>
using namespace std;


int main(){
    int k, n;
    int contador_unos = 0, mayor_contador_unos = 0;
    cout << "Introduce un numero k (numero de unos binarios seguidos): ";
    cin >> k;
    cout << "Introduce un numero n: " ;
    cin >> n;
    int dividendo, cociente, resto;
    dividendo = n;
    while(cociente != 0){
        cociente = dividendo/2;
        resto = dividendo%2;
    if (resto == 1){
        contador_unos++;
    }else{
    contador_unos = 0;
    }
    if (contador_unos > mayor_contador_unos){
    mayor_contador_unos = contador_unos;
    }
    dividendo = cociente;
    }
    if (mayor_contador_unos >= k){
 //cout << "El numero " << n << " SI tiene al menos " << k << " unos binarios repetidos" << endl;
    cout << "Si" << endl;
    }else{
 //cout << "El numero " << n << " NO tiene al menos " << k << " unos binarios repetidos" << endl;
    cout << "No" << endl;
    }
 return 0;
}
