#include <iostream>
using namespace std;


int main(){
    int n, denominador = 1;
    double s = 0;
    do {
        cout << "Introduzca un entero n: ";
        cin >> n;
    }while(n<=0);
    for (int i = 1; i <= n; i++){
    denominador *= 2;
    s += double(i) / double(denominador);
    }
    cout << "Valor de s: " << s;
 return 0;
}
