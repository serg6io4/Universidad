#include <iostream>
using namespace std;
    int main(){
    int n;
    int suma;
    int impar_actual = 1;
    do{
        cout << "Introduce un numero N (mayor que 0) para aplicar la propiedad de Nicomaco de Gerasa: ";
        cin >> n;
    }while(n<=0);
    cout << n << " al cubo = ";
        for (int i = 0; i <= n; i++){
            suma = 0;
            while(suma < i*i*i){
                if (i == n){
                    cout << impar_actual;
                    suma += impar_actual;
                    if (suma < i*i*i){
                        cout << " + ";
                        }
                }else{
                    suma += impar_actual;
                }
                impar_actual += 2;
            }
        }
        cout << " = " << suma;
 return 0;
}

