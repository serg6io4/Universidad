#include <iostream>
using namespace std;

int main(){

    int sumador = 0;
    int i = 0;
    int n = 0;
    cout<<"Introduce un n�mero: ";
    cin>>n;

    /*while(i<=n){
        sumador = sumador + i;
        i++;
    }*/
    /*for(int j = 0; j<=n; j++){
        sumador = sumador + j;
    }*/
    do{
        sumador = sumador+i;
        i++;
    }while(i<=n);

    cout<<"La suma es: "<<sumador;
return 0;
}
