#include <iostream>
using namespace std;


int main(){
    char c;
    int caracteres = 0;
    cout << "Introduzca el texto terminado en un punto: \n";
    cin.get(c); //Permite leer caracteres separadores: � �, �\t�, �\n�
    while (c != '.') {
        caracteres++;
        cout << int(c) << ' ';
        cin.get(c);
    }
    cout << endl << "N�mero de caracteres le�dos: "<< caracteres << endl;
return 0;
}

