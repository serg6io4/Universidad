#include <iostream>
using namespace std;

int main(){

    int i = 8;
    while(i!=0){

        if((i%2) == 0){
            cout<<"BNBNBNBN"<<endl;
        }else{
            cout<<"NBNBNBNB"<<endl;

        }
        i--;
    }





return 0;
}
