#include <iostream>
using namespace std;

int main(){

    int i = 1;
    int n;
    int precio;
    int sumatorio = 0;
    cout<<"Introduzca el numero de modelos de coches: ";
    cin>>n;
    while(i<=n){
        cout<<"Precio del modelo "<<i<<": ";
        cin>>precio;
        sumatorio += precio;
        i++;
    }
    cout<<"El valor medio de los 4 modelos de coche asciende a:"<<sumatorio/(n);



return 0;
}
