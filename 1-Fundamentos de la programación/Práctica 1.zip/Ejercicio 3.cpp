#include <iostream>
using namespace std;
/*El programa en el caso de un valor int lo imprime por pantalla, pero en el caso de la palabra
no procede a tener el mismo tipo de variable por lo que devuelve un valor 0*/
int main(){
    int numero;

    cout << "Introduzca un numero entero: \n";
    cin >> numero;
    cout << numero;

return 0;
}
