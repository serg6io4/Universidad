#include <iostream>
using namespace std;

int main(){

    int numero, Kbytes, Mbytes, resto;
    cout<<"Introduzca un numero natural de bytes: ";
    cin >> numero;

    Mbytes = (numero / (1024*1024));
    Kbytes= (numero / 1024) - Mbytes*1024;
    resto = numero - ((Kbytes*1024)+(Mbytes*1024*1024));

    cout << numero<<": "<< Mbytes<<"Mbytes, "<<Kbytes<<"Kbytes, "<<resto<<"Bytes."<< endl;
}
