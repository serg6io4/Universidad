#include <iostream>
using namespace std;

int main(){
    char a, b, c, d;
    cout << "Escribe cuatro letras:  \n";
    cin >> a>>b>>c>>d;
    cout<<"Su palabra es: "<<a<<b<<c<<d<< endl;
    a=a+1;
    b=b+1;
    c=c+1;
    d=d+1;

    cout <<"Ahora su palabra es: "<<a<<b<<c<<d<<endl;






}
