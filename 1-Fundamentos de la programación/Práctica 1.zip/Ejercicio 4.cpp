#include <iostream>
using namespace std;

int main()
{

    cout << "unsigned: "<<sizeof(unsigned)<< " bytes \n";
    cout << "short: "<<sizeof(short)<< " bytes \n";
    cout << "int: "<<sizeof(int)<< " bytes \n";
    cout << "double: "<<sizeof(double)<< " bytes \n";
    cout << "long: "<<sizeof(long)<< " bytes \n";
    cout << "float: "<<sizeof(float)<< " bytes \n";
    cout << "char: "<<sizeof(char)<< " bytes \n";
    cout << "bool: "<<sizeof(bool)<< " bytes \n";





}
