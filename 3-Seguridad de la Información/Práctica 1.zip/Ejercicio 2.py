def cifradomonoalf(cadena, clave):
	i=0
	resultado = ''
	while i<len(cadena):
		cadenacr = ord(cadena[i])
		clavecr = ord(clave[i%len(clave)])-64
		ordencifrado = 0
		if(cadenacr == 32):
			ordencifrado = 32
		if(cadenacr >= 65 and cadenacr <= 90):
			ordencifrado = (((cadenacr - 65 )+ clavecr )%26) + 65
		resultado = resultado + chr(ordencifrado)	
		i = i + 1
	return resultado

def descifradomonoalf(cadena, clave):
	i=0
	resultado = ''
	while i<len(cadena):
		cadenacr = ord(cadena[i])
		clavecr = ord(clave[i%len(clave)]) - 64
		ordencifrado = 0
		if(cadenacr == 32):
			ordencifrado = 32
		if(cadenacr >= 65 and cadenacr <= 90):
			ordencifrado = (((cadenacr - 65 )- clavecr )% 26) + 65
		resultado = resultado + chr(ordencifrado)	
		i = i + 1
	return resultado




cadena = 'HOLAAMIGOS'
clave = 'CIFRA'
print(cadena +' ; '+ clave)
cifrado = cifradomonoalf(cadena, clave)
print(cifrado)
cifrado = descifradomonoalf(cifrado, clave)
print(cifrado)
