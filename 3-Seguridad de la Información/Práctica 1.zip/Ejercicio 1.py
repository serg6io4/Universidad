#Tiene que admitir letras en mayúsculas y el descifrado César, aparte el descifrado César Generalizado
def cifradoCesarAlfabetoInglesMAY(cadena, n):
    """Devuelve un cifrado Cesar tradicional (+3)"""
    # Definir la nueva cadena resultado
    resultado = ''
    # Realizar el "cifrado", sabiendo que A = 65, Z = 90, a = 97, z = 122
    i = 0
    while i < len(cadena):
        # Recoge el caracter a cifrar
        ordenClaro = ord(cadena[i])
        ordenCifrado = 0
        # Cambia el caracter a cifrar
        if (ordenClaro >= 65 and ordenClaro <= 90):
            ordenCifrado = (((ordenClaro - 65) + n) % 26) + 65
        elif (ordenClaro >= 97 and ordenClaro <= 122):
            ordenCifrado = (((ordenClaro - 97) + n) % 26) + 97
        # Añade el caracter cifrado al resultado
        resultado = resultado + chr(ordenCifrado)
        i = i + 1
    # devuelve el resultado
    return resultado

def descifradoCesarAlfabetoIngles(cadena, n):
    "Devuleve la cadena descifrada"
    #Recibir la cadena
    resultado= ''
    i=0
    while i < len(cadena):
        ordenCesar= ord(cadena[i])
        ordenSinCifrar = 0
        if(ordenCesar >=65 and ordenCesar <=90):
            ordenSinCifrar = (((ordenCesar - 65) - n) % 26) + 65
        elif (ordenCesar >= 97 and ordenCesar <= 122):
            ordenSinCifrar = (((ordenCesar - 97) - n) % 26) + 97
        resultado= resultado + chr(ordenSinCifrar)
        i = i + 1
    return resultado

n = 3
claroCESARMAY = 'VENI VIDI VINCI AURIA'
print(claroCESARMAY)
cifradoCESARMAY = cifradoCesarAlfabetoInglesMAY(claroCESARMAY, n)
print(cifradoCESARMAY)
cifradoCESARMAY = descifradoCesarAlfabetoIngles(cifradoCESARMAY, n)
print(cifradoCESARMAY)