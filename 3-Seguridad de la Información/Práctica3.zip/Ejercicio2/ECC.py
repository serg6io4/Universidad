from Crypto.PublicKey import ECC
from Crypto.Hash import SHA256
from Crypto.Signature import DSS

def crear_ECCKey():
    key = ECC.generate(curve='P-256')
    return key

def guardar_ECCKey_Privada(fichero, key, password):
    key_cifrada = key.export_key(passphrase=password, pkcs=8, protection="PBKDF2WithHMAC-SHA1AndAES128-CBC")
    file_out = open(fichero, "wb")
    file_out.write(key_cifrada)
    file_out.close()

def cargar_ECCKey_Privada(fichero, password):
    key_cifrada = open(fichero, "rb").read()
    key = ECC.import_key(key_cifrada, passphrase=password)
    return key

def guardar_ECCKey_Publica(fichero, key):
    key_pub = key.publickey().export_key()
    file_out = open(fichero, "wb")
    file_out.write(key_pub)
    file_out.close()

def cargar_ECCKey_Publica(fichero):
    keyFile = open(fichero, "rb").read()
    key_pub = ECC.import_key(keyFile)
    return key_pub

#def cifrarECC_OAEP(cadena, key):
    
    #return cifrado

#def descifrarECC_OAEP(cifrado, key):
    
    #return cadena

def firmarECC_PSS(texto, key_private):
    h = SHA256.new(texto.encode("utf-8"))
    signer = DSS.new(key, 'fips-186-3')
    signature = signer.sign(h)
    return signature

def comprobarECC_PSS(texto, firma, key_public):
    h = SHA256.new(received_message)
    verifier = DSS.new(key, 'fips-186-3')
    try:
        verifier.verify(h, signature)
        return True
    except (ValueError, TypeError):
        return False
