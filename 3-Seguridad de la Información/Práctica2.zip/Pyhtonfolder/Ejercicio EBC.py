from Crypto.Random import get_random_bytes
from Crypto.Cipher import DES, AES
from Crypto.Util.Padding import pad,unpad
from Crypto.Util import Counter
import base64
#Creo mi clave y mi IV(ECB NO NECESITA IV)
clave= get_random_bytes(16)
Tamanyo_bloque = 16 #El bloque en AES es de 128 bits
datos = "Hola Amigos de Seguridad".encode("utf-8") #Texto a cifrar
#Se pone el encode porque al ser un string nosotros debemos codificar en bits, para eso sirve.
print(datos)

#CREO EL OBJETO A CIFRAR LUEGO, EN PYTHON SE USAN MÉTODOS CON OBJETOS
objetocifrar = AES.new(clave, AES.MODE_EBC)
#Lo cifro
cifrado = objetocifrar.encrypt(pad(datos, Tamanyo_bloque))#le añado un pading porque mi mensaje no está completo
print(cifrado)
encoded_ciphertext = base64.b64encode(cifrado)
print(encoded_ciphertext)
#Descifrado
descifrado = AES.new(clave, AES.MODE_EBC)

Datos = unpad(descifrado.decrypt(cifrado), Tamanyo_bloque).decode("utf-8","ignore")
print(Datos)