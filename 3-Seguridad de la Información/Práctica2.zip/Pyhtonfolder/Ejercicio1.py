from Crypto.Random import get_random_bytes
from Crypto.Cipher import DES, AES
from Crypto.Util.Padding import pad,unpad
from Crypto.Util import Counter
import base64

class AES_CIPHER_CBC:

    Tamanyo_bloque = 16 # AES: Bloque de 128 bits

    def __init__(self, key):
        """Inicializa las variables locales"""
        self.key = key


    def cifrar(self, cadena, IV):
        """Cifra el parámetro cadena (de tipo String) con una IV específica, y
           devuelve el texto cifrado binario"""
        objetocifrar = AES.new(key, AES.MODE_CBC, IV)
        cifrado = objetocifrar.encrypt(pad(cadena, type(self).Tamanyo_bloque))
        return cifrado

    def descifrar(self, cifrado, IV):
        """Descifra el parámetro cifrado (de tipo binario) con una IV específica, y
           devuelve la cadena en claro de tipo String"""
        descifrado = AES.new(key, AES.MODE_CBC, IV)
        Datos = unpad(descifrado.decrypt(cifrado), type(self).Tamanyo_bloque).decode("utf-8","ignore")
        return Datos

key = get_random_bytes(16) # Clave aleatoria de 128 bits
IV = get_random_bytes(16)  # IV aleatorio de 128 bits
datos = "Hola Mundo con AES en modo CBC".encode("utf-8")
print(datos)
d = AES_CIPHER_CBC(key)
cifrado = d.cifrar(datos, IV)
print(cifrado)
c = base64.b64encode(cifrado)
print(c)
descifrado = d.descifrar(cifrado, IV)
print(descifrado)