package prCuentaPalabrasSimpleColecciones;

public class PalabraEnTexto {

		private String palabra;
		private int veces;
		
		public PalabraEnTexto(String palabra) {
			this.palabra=palabra;
			this.veces=1;
		}
		public void incrementa() {
			this.veces++;
		}
		@Override
		public boolean equals(Object o) {
			boolean ok=false;
			if(o instanceof PalabraEnTexto) {
				PalabraEnTexto otro = (PalabraEnTexto)o;
				if(otro.palabra.compareTo(this.palabra)==0) {
					ok=true;
				}
			}
			return ok;
		}
		public int compareTo(PalabraEnTexto e) {
			return(e.palabra.compareToIgnoreCase(this.palabra));
		}
		@Override
		public int hashCode() {
			return this.palabra.hashCode();
			
		}
		@Override
		public String toString() {
			return "("+this.palabra+": "+this.veces+")" ;
		}
	}