package prCuentaPalabrasSimpleColecciones;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.SortedSet;
import java.util.StringJoiner;
import java.util.TreeSet;

public class ContadorPalabras {

	private SortedSet<PalabraEnTexto> contador;
	
	public ContadorPalabras() {
		contador= new TreeSet<>();
	}
	protected void incluye(String pal) {
		try {
			encuentra(pal).incrementa();
		}catch(NoSuchElementException e) {
			contador.add(new PalabraEnTexto(pal));
		}
	}
	public PalabraEnTexto encuentra(String pal) {
		PalabraEnTexto p = new PalabraEnTexto(pal);
		Iterator <PalabraEnTexto> palabra= contador.iterator();
		while( palabra.hasNext()) {
			if(p.compareTo(palabra.next())==0) {
				return palabra.next();
			}
		}
		throw new NoSuchElementException("No existe esa palabra");
	}
	public void incluyeTodas(String linea, String del) {
		try(Scanner sc = new Scanner(linea)){
			sc.useDelimiter(del);
			while(sc.hasNext()) {
				incluye(sc.next());
			}
		}
	}
	public void incluyeTodas(String [] texto, String del) {
		for(int i=0; i<texto.length;i++) {
			incluyeTodas(texto[i], del);
		}
	}
	public void incluyeTodasFichero(String nomFich, String del) {
		try(Scanner sc = new Scanner(new File(nomFich))){
			leerFichero(sc,del);
		} catch (FileNotFoundException e) {
			System.out.println("No se ha encontrado el fichero"+e);
		}
	}
	private void leerFichero(Scanner sc, String del) {
		while(sc.hasNext()) {
			incluyeTodas(sc.next(), del);
		}
	}
	public void presentaPalabras(String fichero) {
		try {
			PrintWriter pw = new PrintWriter(new File(fichero));
			presentaPalabras(pw);
			pw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void presentaPalabras(PrintWriter pw) {
		for(PalabraEnTexto p: contador) {
			pw.println(p.toString());
		}
	}
	@Override
	public String toString() {
		StringJoiner st = new StringJoiner(",","[","]");
		for(PalabraEnTexto p : contador) {
			st.add(p.toString());
		}
		return st.toString();
	}
}
