package prCuentaPalabrasSimpleColecciones;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collection;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class ContadorPalabrasSig extends ContadorPalabras{
	private Set<String> noSignificativas = new TreeSet<>();

	public ContadorPalabrasSig(Collection<String> c){
		super();
		for(String s: c) {
			noSignificativas.add(s.toUpperCase());
		}
	}
	public ContadorPalabrasSig(String fichNosig, String del){
		super();
		leerFicheros(fichNosig, del);
		
	}
	private void leerFicheros(String fichNosig, String del) {
		try(Scanner sc = new Scanner(new File(fichNosig))){
			sc.useDelimiter(del);
			while(sc.hasNext()) {
				leerPalabrasNoSignificativas(sc.next(), del);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void leerPalabrasNoSignificativas(String next, String del) {
		try(Scanner sc = new Scanner(next)){
			sc.useDelimiter(del);
			while(sc.hasNext()) {
				noSignificativas.add(sc.next().toUpperCase());
			}
		}
	}
	@Override
	protected void incluye(String palabra) {
		if(!noSignificativas.contains(palabra.toUpperCase())) {
			super.incluye(palabra);
		}
	}
	
}
