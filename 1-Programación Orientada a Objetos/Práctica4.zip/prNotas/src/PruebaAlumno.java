import prNotas.Alumno;
import prNotas.AlumnoException;

public class PruebaAlumno {

	public static void main(String[] args) throws AlumnoException {

		Alumno alumno1;
		Alumno alumno2;
		
		alumno1 = new Alumno("Gonzalez Perez, Juan", "22456784F", 5.5);
		alumno2 = new Alumno("Gonzalez Perez, Juan", "22456777S", 3.4);
		
		System.out.println(alumno1);
		System.out.println(alumno2);

	}

}
