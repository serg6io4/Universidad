package prNotas;

public class MediaSinExtremos implements CalculoMedia{

}
