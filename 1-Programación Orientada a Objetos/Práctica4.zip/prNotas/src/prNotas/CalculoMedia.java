package prNotas;

public interface CalculoMedia {

	public double resultado = 0;
	int suma = 0;
	
	public default double calcular(Alumno[] alumnos){
				
		for(int i = 0; i<alumnos.length;i++){
			
			suma += alumnos[i].getCalificacion();
			
		}
		
		return resultado;
		
	}
	
}
