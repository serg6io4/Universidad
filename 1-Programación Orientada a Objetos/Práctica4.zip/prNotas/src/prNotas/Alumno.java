package prNotas;

public class Alumno {

	private String nombre, dni;
	private double nota;
	
	public Alumno(String nombre, String dni, double nota) throws AlumnoException {
		
		this.nombre = nombre;
		this.dni = dni;
		if(nota < 0){
			
			throw new AlumnoException();
			
		}
		
		this.nota = nota;
		
	}
	
	public Alumno(String nombre, String dni){
		
		this.nombre = nombre;
		this.dni = dni;
		this.nota = 0;
		
	}
	
	public boolean equals(Alumno alum){
		
		String nombre=this.getNombre();
		String dni=(this.getDni()).toUpperCase();
		
		if(nombre == alum.getNombre()){
			
			if(dni == (alum.getDni()).toUpperCase()){
				
				return true;
				
			}
		}
		
		return false;
		
	}
	
	public String getNombre(){
		
		return this.nombre;
	}
	
	public String getDni(){
		
		return this.dni;
		
	}
	
	public double getCalificacion(){
		
		return this.nota;
		
	}
	
	
	public String toString(){
		
		return "DNI: " + this.dni + " Nombre: " + this.nombre + " Nota: "+ this.nota;
		
	}
	
}
