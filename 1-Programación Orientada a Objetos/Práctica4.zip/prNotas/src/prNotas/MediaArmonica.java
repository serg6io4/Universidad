package prNotas;

public class MediaArmonica implements CalculoMedia{

}
