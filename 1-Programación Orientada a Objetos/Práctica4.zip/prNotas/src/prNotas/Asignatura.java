package prNotas;

public class Asignatura {

	private String nombre;
	private String[] alumnos;
	private String[] errores;
	
	public Asignatura(String nombre, String[] alumnos) throws AlumnoException{
		
		this.setNombre(nombre);
		this.setAlumnos(alumnos);
		
		for(int i=0; i < alumnos.length; i++) {
			
			String nuevoalumno = alumnos[i];
			String[] aux = nuevoalumno.split(";");
			double nota = Integer.parseInt(aux[2]);
			new Alumno(aux[0], aux[1],nota);
			
		}
	}
	
	public double getCalificacion(Alumno al) throws AlumnoException {
		
		return al.getCalificacion();
		
	}
	
	public String[] getErrores(){
		
		return this.errores;
		
	}

	public String[] getAlumnos() {
		return alumnos;
	}

	public void setAlumnos(String[] alumnos) {
		this.alumnos = alumnos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
}
