package prNotas;

public class AlumnoException extends Exception {

	public AlumnoException() {
		System.out.println("ERROR: Nota negativa.");
	}

	
	
}
