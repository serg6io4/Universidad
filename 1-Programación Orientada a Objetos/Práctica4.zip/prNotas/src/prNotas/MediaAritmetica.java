package prNotas;

public class MediaAritmetica implements CalculoMedia{

	
	
}
