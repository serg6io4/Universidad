package prSeries;
/*
 *Nombre: Sergio Camacho Mar�n
 *Titulaci�n: Ingenier�a Inform�tica
 *Grupo: A
 */
public class Trailer {
	
	private String titulo;
	private int duracion;
	private int capitulo;
	
	public Trailer(int duracion, String titulo, int capitulo) {
		if(duracion<0 || duracion>5) {
			throw new SerieException("No puede ser negativa o durar m�s de 5 minutos");
		}else if(capitulo<0) {
			throw new SerieException("No puede ser negativo el cap�tulo");
		}else if(titulo.substring(0, 8).compareToIgnoreCase("Trailer: ")!=0) {
			throw new SerieException("El t�tulo no pertenece a un trailer");	
		}else {
			this.titulo=titulo;
			this.duracion=duracion;
			this.capitulo=capitulo;
		}
		
	}
}
