package prSeries;
/*
 *Nombre: Sergio Camacho Mar�n
 *Titulaci�n: Ingenier�a Inform�tica
 *Grupo: A
 */
public class Episodio {
	private String titulo;
	private int duracion;
	private int capitulo;
	
	public Episodio(int duracion, String titulo, int capitulo) {
		if(duracion<0) {
			throw new SerieException("No puede ser negativo la duraci�n");
		}else if(capitulo<0) {
			throw new SerieException("No puede ser negativo el cap�tulo");
		}else {
			this.titulo=titulo;
			this.duracion=duracion;
			this.capitulo=capitulo;
		}
		
	}
//Utilizo getters/setters de la pesta�a source
	public String getTitulo() {
		return titulo;
	}

	public int getDuracion() {
		return duracion;
	}

	public int getCapitulo() {
		return capitulo;
	}
	@Override
	public boolean equals(Object o) {
		boolean ok=false;
		if(o instanceof Episodio) {
			Episodio otro= (Episodio)o;
			if(this.titulo.compareToIgnoreCase(otro.titulo)==0
					&& this.duracion==otro.duracion) {
				ok=true;
			}
		}
		return ok;
		
	}
	@Override
	public int hashCode() {
		return this.titulo.toUpperCase().hashCode()+Integer.hashCode(this.duracion);
		
	}
	@Override
	public String toString() {
		return "Episodio: "+this.capitulo+":"+this.titulo+"   ("+this.duracion+"min"+")";
	}
}
