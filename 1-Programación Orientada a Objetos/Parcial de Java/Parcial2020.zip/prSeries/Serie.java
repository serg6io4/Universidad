package prSeries;
/*
 *Nombre: Sergio Camacho Mar�n
 *Titulaci�n: Ingenier�a Inform�tica
 *Grupo: A
 */
public class Serie {
	
	private String titulo;
	private Episodio [] episodios;
	
	public Serie(String titulo,String [] episodios) {
		this.titulo=titulo;
		this.episodios= new Episodio[episodios.length];
		for(int i = 0; i<episodios.length;i++) {
			String[] partes = episodios[i].split(":");
			try {
			Episodio ep = new Episodio(Integer.parseInt(partes[2]),partes[1],Integer.parseInt(partes[0]));
			this.episodios[i]=ep;
			}catch(SerieException e) {
				System.out.println("Se ha producido un error en la inserci�n"+e.getMessage());
			}
		}
	}
	
	public int duracionTotal() {
		int suma=0;
		for(int i=0; i<this.episodios.length; i++) {
			suma+=this.episodios[i].getDuracion();
		}
		return suma;
	}
	
	public Episodio obtenerEpisodio(int capitulo) {
		Episodio ep = null;
		for(int i=0; i<this.episodios.length;i++) {
			if(this.episodios[i].getCapitulo()==capitulo){
				ep=this.episodios[i];
			}
		}
		return ep;
	}
	@Override
	public String toString() {
		String cadena=this.titulo+ "->"+ "[";
		for(int i=0; i<this.episodios.length;i++) {
			if(i==this.episodios.length-1) {
				//Si es el �ltimo que no ponga una coma, que cierre con par�ntesis
				cadena+=this.episodios[i].toString()+"]";
			}else {
			cadena+=this.episodios[i].toString()+", ";
			}
		}
		return cadena;
	}
}
