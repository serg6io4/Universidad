package prSeries;
/*
 *Nombre: Sergio Camacho Mar�n
 *Titulaci�n: Ingenier�a Inform�tica
 *Grupo: A
 */
public class SerieException extends RuntimeException{
//Pongo runtimeexception porque se pide no comprobada
	/**
	 SerialVersionUID 
	 */
	private static final long serialVersionUID = 9217263046026732214L;
	
	public SerieException() {
		super();
	}
	public SerieException(String msg) {
		super(msg);
	}
}
