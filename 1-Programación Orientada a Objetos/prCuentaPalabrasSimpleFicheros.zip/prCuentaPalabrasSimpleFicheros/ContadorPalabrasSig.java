package prCuentaPalabrasSimpleFicheros;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ContadorPalabrasSig extends ContadorPalabras{
	private String [] noSignificativas;
	private static final int TAM=10;
	private int  numPalNoSig;
	
	public ContadorPalabrasSig(String [] palsNs) {
		super();
		noSignificativas = palsNs;
		numPalNoSig=palsNs.length;
	}
	public ContadorPalabrasSig(int n , String [] palsNs) {
		super(n);
		noSignificativas = palsNs;
		numPalNoSig=palsNs.length;
	}
	public ContadorPalabrasSig(String fileNoSig , String del) throws FileNotFoundException {
		super();
		noSignificativas= new String[TAM];
		numPalNoSig=0;
		leerFicheroNoSig(fileNoSig, del);
	}
	public ContadorPalabrasSig(int n,String fileNoSig , String del) {
	
	}
	private void leerFicheroNoSig(String FicheroNoSig, String del) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(FicheroNoSig));
		leerFicheroNoSig(sc, del);
	}
	private void leerPalabrasNoSignificativas(String fileNoSig, String del) {
		Scanner sc = new Scanner(fileNoSig);
		sc.useDelimiter(del);
		while(sc.hasNext()) {
			incluye(sc.next());
		}
		sc.close();
	}
	private void leerFicheroNoSig(Scanner sc, String del) {
		while(sc.hasNextLine()) {
			leerPalabrasNoSignificativas(sc.nextLine(),del);
		}
		sc.close();

	}
	@Override
	protected void incluye(String pal) {
		super.incluye(pal);
	}
}
