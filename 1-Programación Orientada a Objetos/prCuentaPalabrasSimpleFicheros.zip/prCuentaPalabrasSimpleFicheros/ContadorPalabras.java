package prCuentaPalabrasSimpleFicheros;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class ContadorPalabras {
	private int numPalabras;
	private static final int TAM_INICIAL=10;
	private PalabraEnTexto [] palabras;
	
	public ContadorPalabras() {
		this(TAM_INICIAL);
	}
	public ContadorPalabras(int tam) {
		this.numPalabras=0;
		this.palabras= new PalabraEnTexto[tam];
	}
	
	private int esta(String pal) {
		PalabraEnTexto p = new PalabraEnTexto(pal);
		int encontrado=-1;
		int i=0;
		while(encontrado==-1 && i<palabras.length) {
			if(palabras[i].equals(p)) {
				encontrado=i;
			}
			i++;
		}
		return encontrado;
	}
	protected void incluye(String pal) {
		int resultado = esta(pal);
		if(numPalabras==palabras.length) {
			System.out.println("Est� lleno, pero se crea nuevo tama�o");
			palabras=Arrays.copyOf(palabras, 2*palabras.length);
		}
		if(resultado!=-1) {//No la encuentra
			PalabraEnTexto p= new PalabraEnTexto(pal);
			palabras[numPalabras]=p;
			numPalabras++;
		}else {//la encuentra
			palabras[resultado].incrementa();
		}
	}
	private void incluyeTodas(String linea, String del) {
		try(Scanner sc = new Scanner(linea) ){
			sc.useDelimiter(del);
			while(sc.hasNext()) {
				incluye(sc.next());
			}
		}
	}
	public void incluyeTodas(String [] texto, String del) {
		for(int i =0; i<texto.length;i++) {
			incluyeTodas(texto[i],del);
		}
	}
	
	public PalabraEnTexto encuentra(String pal) {
		PalabraEnTexto p = null;
		int encontrado = esta(pal);
		if(encontrado==-1) {
			throw new NoSuchElementException("No existe");
		}else {
			p=palabras[encontrado];
		}
		return p;
	}
	public void incluyeTodasFichero(String nomFich, String del) throws FileNotFoundException {
		try(Scanner sc = new Scanner(new File(nomFich))){
			leerFichero(sc, del);
		}
	}
	private void leerFichero(Scanner sc, String del) {
		while(sc.hasNextLine()) {
			incluyeTodas(sc.nextLine(),del);
		}
	}
	@Override
	public String toString() {
		return Arrays.toString(Arrays.copyOfRange(palabras, 0, numPalabras));
	}
	public void presentaPalabras(String fichero) throws FileNotFoundException {
		PrintWriter fich= new PrintWriter(fichero);
		presentaPalabras(fich);
	}
	public void presentaPalabras(PrintWriter fich) {
		for(int i =0; i<numPalabras; i++) {
			fich.println(palabras[i].toString());
		}
		fich.close();
	}
}
