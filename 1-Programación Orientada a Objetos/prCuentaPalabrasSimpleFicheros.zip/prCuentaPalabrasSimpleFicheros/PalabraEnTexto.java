package prCuentaPalabrasSimpleFicheros;

public class PalabraEnTexto {
	private String palabra;
	private int veces;
	
	public PalabraEnTexto(String palabra) {
		this.palabra=palabra;
		this.veces=1;
	}
	public void incrementa() {
		this.veces++;
	}
	@Override
	public boolean equals(Object o) {
		boolean ok=false;
		if(o instanceof PalabraEnTexto) {
			PalabraEnTexto pal= (PalabraEnTexto) o;
			if(this.palabra.equalsIgnoreCase(pal.palabra)) {
				return true;
			}
		}
		return ok;
	}
	@Override
	public int hashCode() {
		return this.palabra.hashCode();
		
	}
	@Override
	public String toString() {
		return "("+this.palabra+": "+this.veces+")" ;
	}
}
