package prDatos;

import java.util.Arrays;

public class Datos {

	private double [] datos;
	private String [] errores;
	private double min;
	private double max;
	
	public Datos(String [] secuencia, double m, double M) {
		min=m;
		max=M;
		int k=0;
		int j=0;
		double num = 0.0;
		
		for(int i=0; i<secuencia.length;i++) {
			try {
				num=Double.parseDouble(secuencia[i]);
				datos = Arrays.copyOf(datos, k+1);
				datos[k]= num;
				k++;
			}catch(NumberFormatException e) {
				errores=Arrays.copyOf(errores, j+1);
				errores[j]= secuencia[i];
				j++;
			}
		}
	}
	public double calcMedia() throws DatosException {
		int contador=0;
		int sum=0;
		
		for(int i=0; i<datos.length;i++) {
			if(datos[i]>min && datos[i]<max) {
				sum+=datos[i];
				contador++;
			}
		}
		if(contador==0) {
			throw new DatosException("No hay datos en el rango especificado");
		}
		return sum/contador;
	}
	public double calcDesvTipica() throws DatosException{
		int contador=0;
		int suma=0;
		try {
			double media=calcMedia();
			for(int i=0; i<datos.length;i++) {
				if(datos[i]>min && datos[i]<max) {
					suma+=Math.pow(datos[i]-media, 2);
					contador++;
				}
			}
		return suma/contador;
		}catch(DatosException e) {
			throw new DatosException("No hay datos espec�ficos dentro del rango");
		}
	}
	public void setRango(String minmax) {
		try {
		int pos= minmax.indexOf(";");
		min= Double.parseDouble(minmax.substring(0, pos));
		max=Double.parseDouble(minmax.substring(pos,minmax.length()));
		}catch(StringIndexOutOfBoundsException e) {
			throw new DatosException("Error en los datos al establecer\r\n" + 
					"el rango");
		}catch(NumberFormatException e) {
			throw new DatosException("Error en los datos al establecer\r\n" + 
					"el rango");
		}
		
	}
	public double[] getDatos() {
		return datos;
	}
	public String[] getErrores() {
		return errores;
	}
	@Override
	public String toString() {
		try {
			return "Min:"+min+", Max:"+max+"\n"+
					datos.toString()+",\n"+ errores.toString()+",\n"+
								"Media:"+ calcMedia()+", DesvTipica:"+calcDesvTipica();
		}catch(DatosException e) {
			return "Min:"+min+", Max:"+max+"\n"+
					datos.toString()+",\n"+ errores.toString()+",\n"+
								"Media: ERROR"+", DesvTipica:ERROR";
		}
		
	}
		
}

